# Judo Mind Software Architecture

## Document Information

Project:
Judo Mind Super App

Document:
Software Architecture

Version:
1.3

Status:
Approved Architecture Baseline

Last Updated:
2026-08-08

---

# 1. Project Overview

## Project Name

Judo Mind Super App

## Product Type

Judo Mind is a global digital Judo ecosystem.

It is not limited to a Flutter mobile application.

The complete product ecosystem will include:

- Mobile applications
- Web platforms
- Administration Panel
- Content Management System
- Backend services
- Artificial Intelligence services
- Athlete systems
- Coach systems
- Club systems
- Federation systems
- Educational platforms
- Judo knowledge infrastructure

## Current Implementation Platform

Flutter Mobile Application

## Long-Term Platforms

- Android
- iOS
- Web
- Desktop administration platform
- Federation dashboards
- Club dashboards
- Coach dashboards
- Athlete dashboards

## Goal

Create a professional global Judo ecosystem connecting:

- Athletes
- Coaches
- Clubs
- Federations
- Referees
- Educators
- Fans
- Parents
- Administrators
- Judo organizations

The system must be:

- Scalable
- Secure
- Maintainable
- Multilingual
- Commercially ready
- Enterprise ready
- Investor ready
- Federation ready
- AI ready
- Cloud ready

---

# 2. Final Architecture Vision

Judo Mind is designed as:

A global digital Judo ecosystem powered by Judo knowledge,
sports science, technology, data and artificial intelligence.

The system architecture follows this hierarchy:

Business Vision

↓

Product Architecture

↓

Domain Architecture

↓

Knowledge Architecture

↓

Technical Architecture

↓

Backend and Cloud Infrastructure

↓

Flutter and Web Implementations

---

# 3. Architecture Principles

Judo Mind follows these architectural principles:

- Clean Architecture
- Feature-based development
- Domain-driven organization
- Modular design
- Reusable components
- Separation of concerns
- One Source of Truth
- Documentation-first development
- Security-first development
- Localization-first development
- CMS-first content architecture
- API-first backend preparation
- Scalability-oriented development
- Testable architecture
- Accessibility-aware design
- Enterprise-ready infrastructure
- No unnecessary technical debt

## Main Objectives

- Easy maintenance
- Fast feature development
- Safe refactoring
- Team collaboration
- Independent module development
- Future backend integration
- Future web integration
- Future federation integration
- Clear ownership of data
- Consistent user experience
- Reduced code duplication
- Long-term product scalability

---

# 4. Architectural Layers

Judo Mind consists of several connected architecture layers.

## 4.1 Business Layer

Defines:

- Business model
- Subscription plans
- Federation licensing
- Club licensing
- Advertisements
- Sponsorships
- Premium services
- Marketplace services
- Educational products
- AI services
- Commercial partnerships

## 4.2 Product Layer

Defines:

- Product goals
- User groups
- Product requirements
- Module requirements
- User journeys
- Feature priorities
- Success metrics
- Release roadmap

## 4.3 Domain Layer

Defines major product domains:

- Athlete
- Coach
- Club
- Federation
- Techniques
- Training
- Competition
- Monitoring
- Education
- Artificial Intelligence
- Content
- Administration
- Commerce
- Community

## 4.4 Knowledge Layer

Defines the structured knowledge used throughout the ecosystem.

## 4.5 Application Layer

Contains:

- Use cases
- Business operations
- State coordination
- Validation
- Application services

## 4.6 Data Layer

Contains:

- Repositories
- Data sources
- API clients
- Database access
- Cache access
- Content synchronization
- Media services

## 4.7 Presentation Layer

Contains:

- Screens
- Widgets
- Controllers
- Providers
- View models
- User interactions
- Navigation
- Accessibility behavior

## 4.8 Infrastructure Layer

Contains:

- Backend services
- Cloud infrastructure
- Authentication
- Storage
- Analytics
- Monitoring
- Notifications
- Security
- AI services

---

# 5. Current Flutter Architecture

The current Flutter project uses the following structure:

```text
lib/
├── core/
├── models/
├── screens/
├── widgets/
├── services/
├── routes/
└── main.dart
```
## Core UI Layer

Judo Mind uses a reusable component-based UI architecture.

Location:

lib/core/widgets/

Components:

- JudoCard
- JudoSection
- JudoSectionTitle
- JudoBadge
- JudoButton

Purpose:

Provide consistent visual language across all 18 modules.

## Judo Mind Design System Icon Architecture

Judo Mind uses a centralized icon architecture.

### Registry

Location:

`lib/core/design_system/icons/judo_icons.dart`

Responsibilities:

- Register all temporary and final Judo Mind icons.
- Prevent direct icon selection inside feature screens.
- Provide stable semantic names such as:
  - `JudoIcons.kuzushi`
  - `JudoIcons.balance`
  - `JudoIcons.combination`
  - `JudoIcons.aiCoach`
- Allow future replacement of temporary Material icons without changing feature architecture.

### Standard Widget

Location:

`lib/core/design_system/widgets/judo_icon.dart`

Responsibilities:

- Control icon size.
- Control icon background treatment.
- Apply semantic accessibility labels.
- Provide selected, highlighted and disabled presentation.
- Act as the future rendering layer for SVG icons.

### Feature Rule

Feature screens must not create independent icon styles.

Icons must be accessed through:

1. `JudoIcons`
2. `JudoIcon`
3. Approved JMDS illustration components

Material icons may remain only as temporary registry implementations or generic platform actions.

## Judo Mind Illustration Architecture

Illustrations are rendered through the centralized JMDS layer.

Locations:

- `lib/core/design_system/illustrations/judo_illustration_type.dart`
- `lib/core/design_system/illustrations/judo_illustration.dart`

Feature screens must reference semantic illustration types rather than implement their own drawings.

High-value illustrations are used selectively. Standard dashboard items remain icon-based to prevent excessive visual density.

## Official Product Module Boundary

Judo Mind contains 18 official product modules. JM-DEC-020 adds `AI Training
Plan Intelligence` as Module 18 without changing the ownership of the existing
17 modules.

### Module 18 - AI Training Plan Intelligence

Module 18 accepts a training plan supplied by an athlete or coach and evaluates
it against disclosed context and evidence. Its architecture must remain
separate from the Training Center content experience and the Monitoring data
domain while consuming their approved context through explicit interfaces.

Required context includes:

- Training season or period
- Time remaining to competition
- Athlete context supplied by an authorized user
- Evidence-based strength and conditioning principles
- Physiology, recovery and training-load principles
- Judo-specific performance requirements
- Academic or primary scientific evidence

The analysis contract must distinguish supported elements from questionable,
risky or internally inconsistent elements; explain the reasoning; cite evidence
and provenance; expose uncertainty and limitations; and propose alternatives
only when justified. Recommendations are AI-inferred decision support, not a
medical diagnosis and not proof that one universal training plan is correct.

This decision establishes the architecture and product boundary only. No Module
18 Flutter UI, backend service or automated plan modification is implemented.

---

# 6. AI & Scientific Biomechanics Architecture

## 6.1 Objective

Judo Mind AI must provide scientifically meaningful and practically useful Judo analysis.

Pose-estimation skeletons alone are not considered biomechanical analysis.

The system must evolve from visual pose detection into a complete Judo-specific motion intelligence platform.

Uchi Mata remains the reference technique for development and validation.

---

## 6.2 Biomechanics Architecture

The approved scientific pipeline is:

Video Capture

↓

Camera Calibration and Synchronization

↓

Tori / Uke Detection

↓

Multi-Person 2D Pose Estimation

↓

Identity and Occlusion Intelligence

↓

Multi-View 3D Reconstruction

↓

3D Anatomical Motion Data

↓

OpenSim Musculoskeletal Modeling

↓

Judo-Specific Biomechanical Analysis

↓

Technique Phase Intelligence

↓

Confidence and Scientific Quality Control

↓

Athlete / Coach Report

---

## 6.3 Computer Vision Layer

The Computer Vision layer is responsible for:

- Athlete detection
- Multi-person pose estimation
- Tori / Uke separation
- Joint landmark detection
- Temporal tracking
- Occlusion detection
- Video frame analysis

Current evaluated technologies:

- MediaPipe Pose Landmarker Heavy
- RTMPose-M
- RTMPose PoseTracker
- RTMO-M

### Current Benchmark

All models were evaluated using the same real Judo competition video.

MediaPipe Heavy:

- At least one athlete detected: 99.63%
- Two athletes detected: 31.48%

RTMPose-M:

- At least one athlete detected: 97.04%
- Two athletes detected: 48.33%

RTMPose-M + PoseTracker:

- At least one athlete detected: 96.85%
- Two athletes detected: 46.85%

RTMO-M:

- At least one athlete detected: 40.56%
- Two athletes detected: 8.15%

### Current Baseline Decision

RTMPose-M is the approved current baseline pose-estimation engine.

Pose estimation is an input layer and must not be presented as the complete biomechanics engine.

Generic pose-estimation models will eventually be supplemented by Judo-specific detection, identity and occlusion intelligence.

---

## 6.4 Musculoskeletal Biomechanics Layer

OpenSim 4.6 is the approved primary musculoskeletal modeling engine.

Current development environment:

- Python 3.12
- OpenSim 4.6
- NumPy 2.5.1
- Windows development environment

OpenSim has been installed and successfully initialized inside a dedicated environment:

`ai_engine/.biomech_venv`

The Computer Vision environment remains isolated:

`ai_engine/.venv`

This separation prevents computer-vision dependencies from conflicting with scientific biomechanics dependencies.

### OpenSim Responsibilities

OpenSim will support:

- Musculoskeletal modeling
- Segment orientation
- Joint kinematics
- Joint angles
- Range of motion
- Center-of-mass calculations
- Angular velocity
- Angular acceleration
- Inverse kinematics
- Inverse dynamics when valid external-force data is available
- Joint moments
- Joint powers
- Musculoskeletal simulation

---

## 6.5 Multi-View 3D Architecture

High-quality biomechanical analysis must not rely only on a single uncalibrated 2D video.

The advanced Judo Mind analysis mode will support two or more synchronized cameras or smartphones.

Multi-view processing will include:

- Camera calibration
- Camera synchronization
- 2D landmark detection per camera
- Cross-camera athlete identity matching
- Multi-view triangulation
- 3D anatomical landmark reconstruction
- Temporal filtering
- Quality validation

The resulting 3D motion data will be prepared for OpenSim processing.

---

## 6.6 Judo-Specific Interaction Intelligence

Standard human-motion models are insufficient for Judo because two athletes frequently:

- Touch
- Grip
- Cross limbs
- Rotate together
- Occlude each other
- Enter close body contact
- Change orientation rapidly
- Move through throwing and landing phases

Therefore Judo Mind requires a dedicated interaction layer.

The system must understand:

- Tori
- Uke
- Grip relationship
- Relative stance
- Support base
- Distance
- Kuzushi direction
- Weight transfer
- Tsukuri entry
- Hip position
- Leg position
- Rotation
- Kake
- Throw trajectory
- Counter movement
- Landing

---

## 6.7 Uchi Mata Biomechanical Reference Model

Uchi Mata will be the first complete technique-specific biomechanical model.

The reference system must eventually analyze:

- Initial stance
- Grip configuration
- Kuzushi direction
- Entry angle
- Support-leg position
- Attacking-leg trajectory
- Hip position
- Trunk inclination
- Pelvis rotation
- Knee angles
- Shoulder rotation
- Center-of-mass trajectory
- Tori / Uke relative position
- Tsukuri timing
- Kake timing
- Rotation velocity
- Throw completion
- Landing control

Once scientifically and technically validated, the architecture will be generalized to the remaining 66 official techniques.

---

## 6.8 Analysis Quality Levels

### Standard Video Analysis

Input:

- One training or competition video

Capabilities:

- Technical analysis
- Tactical analysis
- Pose estimation
- Technique recognition
- Phase detection
- Estimated movement metrics

Scientific classification:

Estimated

---

### Advanced Biomechanics

Input:

- Two or more synchronized and calibrated cameras

Capabilities:

- Multi-view 3D reconstruction
- Improved joint kinematics
- Center-of-mass analysis
- Segment orientation
- Tori / Uke interaction
- Technique-specific biomechanics

Scientific classification:

3D Estimated / Model-Based

---

### Research and Validation Mode

Possible inputs:

- Marker-based motion capture
- Force plates
- EMG
- IMU sensors
- Laboratory reference systems

Purpose:

- Validation
- Research collaboration
- Algorithm evaluation
- Accuracy measurement
- Model improvement

---

## 6.9 Scientific Integrity

Judo Mind must distinguish between:

- Measured data
- Reconstructed data
- Model-estimated data
- AI-inferred data

The application must never present estimated values as directly measured physical quantities.

Examples:

Force plate ground reaction force:

Measured

Video-derived ground reaction force:

Estimated

EMG muscle activity:

Measured

OpenSim-derived muscle activation:

Model Estimated

Every professional biomechanical result should eventually include:

- Confidence score
- Data source
- Analysis method
- Quality level
- Relevant limitations

---

## 6.10 Scientific Reference Direction

The Judo Mind biomechanics architecture is informed by established biomechanics workflows including:

- Marker-based motion capture
- Markerless multi-camera motion capture
- OpenCap-style multi-view analysis
- OpenSim musculoskeletal modeling
- Force-plate integration
- EMG integration
- Sports-science validation

OpenCap architecture may be used as an engineering and scientific reference where appropriate.

Judo Mind will not depend on the hosted OpenCap service.

Judo Mind will develop its own Judo-specific multi-person analysis architecture.

---

## 6.11 AI Infrastructure

Local CPU processing is intended for:

- Development
- Benchmarking
- Architecture validation
- Debugging

Production high-accuracy processing will use GPU-backed infrastructure.

AI services must remain separated from the Flutter presentation layer.

Flutter responsibilities:

- Capture
- Upload
- User interaction
- Analysis configuration
- Result visualization

AI backend responsibilities:

- Computer vision
- Pose estimation
- 3D reconstruction
- Biomechanics
- OpenSim processing
- Judo intelligence
- Report generation

---

## 6.12 Scientific Validation Requirement

A biomechanics feature is not considered production-grade only because its code executes successfully.

Validation must include:

- Repeatability testing
- Accuracy testing
- Real Judo footage
- Different camera angles
- Different body sizes
- Different judogi colors
- Left and right stance
- Occlusion
- Competition speed
- Training speed
- Expert Judo review

Where possible, advanced validation should compare Judo Mind results against:

- Laboratory motion capture
- Force plates
- EMG
- Expert technical annotation

Scientific validation is part of the product architecture, not an optional future enhancement.

---

## 6.13 Dual-Level Video Analysis Boundary

JM-DEC-018 makes the analysis level an explicit architectural boundary rather than a presentation label.

### Single-Camera AI Analysis Pipeline

Input:

- One ordinary training or competition video

Pipeline:

1. Ingest and validate media metadata.
2. Estimate 2D pose and confidence.
3. Detect defensible phases, timing and visible movement patterns.
4. Apply Judo-specific technical or tactical inference.
5. Publish only outputs supported by the available view, with confidence and limitations.

Allowed provenance:

- `model-estimated`
- `AI-inferred`
- `measured` only for directly observed media properties such as timestamps or pixel dimensions

Prohibited claims:

- Reconstructed 3D motion
- Directly measured joint kinetics or force
- Precise biomechanics when depth or physical quantities were not scientifically recovered

### Multi-Camera 3D Scientific Analysis Pipeline

Input:

- Two or more synchronized camera streams suitable for cross-camera processing

Required sequence:

1. Media and camera identity validation
2. Intrinsic and extrinsic calibration evidence
3. Fail-closed calibration quality gate
4. Synchronization quality gate
5. Cross-camera Tori/Uke identity and landmark correspondence
6. Geometry and triangulation quality gate
7. Reconstructed 3D motion with confidence and provenance
8. Motion and anatomical suitability gates
9. OpenSim processing when all upstream gates pass
10. Judo-specific biomechanical interpretation and report-quality gate

If any required gate fails, the advanced pipeline stops. It must not silently fall back while retaining a 3D, scientific-biomechanics or OpenSim label. A separately requested Single-Camera AI analysis may still be offered under its own estimated/inferred classification.

### Calibration Quality Profiles

The centralized calibration gate consumes the recorded JSON evidence and requires `status=completed`, an accepted quality label and every required finite, non-negative metric.

Offline 3D validation profile:

- Accepted quality: `usable_for_3d_validation`, `good` or `excellent`
- Minimum valid stereo holds: 8
- Maximum RMS reprojection error: 3.0 px
- Maximum median epipolar error: 2.0 px
- Maximum median absolute sync error: 9.0 ms
- Output is development/validation-only and cannot be exposed as user-facing scientific 3D

Scientific 3D and minimum OpenSim calibration profile:

- Accepted quality: `good` or `excellent`
- Minimum valid stereo holds: 10
- Maximum RMS reprojection error: 2.0 px
- Maximum median epipolar error: 1.25 px
- Maximum median absolute sync error: 8.5 ms

These values preserve the current calibration quality classification. Future threshold changes require scientific validation and a recorded decision.

### Runtime Enforcement

`MultiViewReconstructor` requires a sealed `ValidatedCalibrationContext` created by the centralized gate. Raw projection matrices without approved calibration context are insufficient, and every camera projection must carry the same calibration identity as that context. Each reconstructed point carries `reconstructed` provenance, calibration identity, requested calibration purpose and whether the context permits user-facing scientific 3D.

`quality=review_required`, missing evidence, malformed evidence or any exceeded threshold is rejected by default.

### OpenSim Boundary

An OpenSim-purpose calibration context proves only that the calibration portion of the pipeline passed its minimum profile. It does not prove that the motion is suitable for OpenSim. Cross-camera identity, temporal alignment, reconstruction confidence, marker/anatomical mapping and motion quality require independent approval before musculoskeletal processing.

### Closed 2026-08-07 Calibration Cycle

The current two-phone extrinsic has RMS 48.2750333 px, median epipolar error 55.4328918 px and quality `review_required`. It is blocked from offline 3D validation, user-facing scientific 3D and OpenSim. The current pair is retained as evidence, but its source videos must not be tested again. Stabilization/EIS/OIS virtual-camera change is recorded only as an unconfirmed hypothesis.

---

## 6.14 Three-Level Fight Intelligence 360 Architecture

JM-DEC-019 expands the product-level analysis architecture from the two operational video pipelines in JM-DEC-018 into three explicit scientific levels. It does not weaken or remove the Single-Camera/Multi-Camera boundary or any calibration safeguard.

### Level 1 - Single-Camera AI Analysis

One ordinary video may produce measured media metadata, model-estimated projected 2D kinematics and AI-inferred phases or coaching observations. Spatial results must use `projected` or `image-plane` language. True/reconstructed 3D, true 3D COM, measured force, actual joint moment, torque or power are prohibited.

### Level 2 - Multi-Camera 3D Analysis

The required pipeline is:

`synchronization -> intrinsics -> extrinsics -> orientation -> cross-camera Tori/Uke identity -> correspondence -> triangulation -> 3D reconstruction -> filtering -> confidence/quality gates -> 3D metrics`

Only a run that passes every gate may publish reconstructed 3D landmarks, trajectories, geometric joint angles, relative position, velocity, model-estimated COM or interactive 3D/360 viewing. `review_required` remains rejected. The failed 2026-08-07 dataset is evidence of an invalid capture/calibration cycle, not a reason to remove the Level 2 architecture.

### Level 3 - Professional / Federation / Laboratory Analysis

This level may combine synchronized high-speed cameras, a calibrated capture volume, marker-based or validated markerless capture, optional IMUs, force plates or other external-force instrumentation, EMG where approved, and OpenSim. It supports high-quality 3D kinematics and only supports kinetics/inverse dynamics when valid external-force and model evidence is available.

Level 3 is the reference-validation environment for Levels 1 and 2. Laboratory context alone does not authorize a measured or kinetic claim.

### Metric Registry Boundary

The versioned scientific contract is `docs/UCHI_MATA_SCIENTIFIC_METRICS_V1.md`. Every metric must declare its ID, role, phase/event schema, method, unit, minimum input, valid level, provenance, confidence evidence, source and prohibited interpretation. No threshold or normative target may be introduced without supporting evidence, validation and a recorded decision.

### Interactive 3D / 360

Interactive viewing is a virtual camera over a validated reconstructed scene. It provides Front, Side, Rear, Top and Free 360 views and must be described as `3D reconstruction + 360 viewing`, not 360-camera capture. Athlete-versus-reference comparison may show compatible angle, time and position differences but must not treat a single champion, trial or incompatible phase schema as a universal ideal.

### Result Presentation

Fight Intelligence results coordinate AI Sensi, annotated video, voice coaching, a scientific report and, when Level 2/3 evidence permits, interactive 3D/360. Blue represents movement/position/joint geometry; Gold represents grip/Hikite/Tsurite/upper-body control; Green represents balance/COM/mechanical direction. At Level 1, Green directional arrows are AI-inferred conceptual coaching cues, never measured force vectors.

---

## 6.15 Video Analysis Mode Architecture

JM-DEC-021 defines three analysis modes around user intent and temporal scope.
They are orthogonal to the scientific Levels in section 6.14: an analysis mode
does not promote provenance or bypass the Single-Camera/Multi-Camera gates.

### Mode 1 - Single Attempt Technique Analysis

Purpose:

Deep analysis of one primary execution of a selected technique such as Uchi
Mata.

Input boundary:

- Useful context immediately before the attempt
- One primary technique attempt
- Useful context immediately after completion or landing

One analysis window equals one primary attempt. No universal duration threshold
is approved. If a video contains multiple attempts and automatic event
segmentation is not validated, the user or reviewer must select or trim one
attempt. Unsegmented executions must not be averaged or presented as one
technical result.

Future result composition:

- Annotated Video
- AI Sensi
- Voice Coaching
- Scientific Report
- Interactive 3D/360 only when Level 2/3 scientific gates permit it

### Mode 2 - Drill / Repeated Attempts Analysis

Purpose:

Analyze repeated practice of the same technique without losing the identity of
each repetition.

Pipeline:

`drill video -> attempt/event segmentation -> per-attempt analysis -> reviewed comparison -> permitted aggregate statistics`

Each repetition becomes Attempt 1, Attempt 2, Attempt 3 and so on. The system
may compare validated metrics for consistency, variability, progression,
degradation and repeatability only after reliable segmentation and independent
per-attempt analysis. It must never blend several repetitions into one
execution. Fatigue-related interpretation requires separately validated
evidence and must not be inferred merely from change across attempts.

### Mode 3 - Full Match Analysis

Purpose:

Analyze a complete competition or match independently from Technique Analysis.

Pipeline:

`full match -> temporal event detection -> attack/event segmentation -> technique candidate/classification -> individual attempt analysis -> outcome -> next event -> match-level tactical aggregation`

Output layers remain separate:

1. Event timeline
2. Individual attack cards
3. Per-attempt analysis
4. Match tactical summary
5. AI Sensi competition review

All attacks must not be blended into one biomechanics report. Match-level
tactical metrics and individual technique-analysis results are different data
products with independent methods, confidence and limitations.

### Pose Benchmark Boundary

The Pose Engine Benchmark is engineering/evaluation infrastructure. Its purpose
is person detection coverage, two-person coverage, engine reliability and
processing performance. A benchmark video may contain several movements or
repetitions, but benchmark observations are not athlete Technique Analysis and
do not authorize combined execution findings.

The timestamp-based 10 FPS target belongs to the benchmark infrastructure only.
Future scientific metric extraction must preserve source timestamps and use an
appropriately validated temporal resolution. Depending on the metric and event,
this may require native 25, 30, 50 or 60 FPS. No universal biomechanics FPS is
approved without validation.

### Scientific and Product Gates

Every mode preserves `measured`, `reconstructed`, `model-estimated` and
`AI-inferred` provenance. Validated identity is required before Tori/Uke claims,
and validated event/phase segmentation is required before automatic
Kuzushi/Tsukuri/Kake judgments. Ordinary video cannot produce measured force;
single-camera input cannot produce true 3D or actual torque, moment or power.

The future Analyze experience presents the modes in judoka/coach language:

- Technique Analysis -> One Attempt
- Training / Drill Analysis -> Multiple Repetitions
- Competition Analysis -> Full Match

The coordinated result architecture remains AI Sensi + Annotated Video + Voice
Coaching + Scientific Report + Interactive 3D/360 when scientifically
available.

---

## 6.16 Single-Attempt Uchi Mata V2A Implementation

JM-DEC-022 implements the first bounded Level 1 Single Attempt result without
promoting the unvalidated automatic identity or phase layers.

### Contract Flow

`human-reviewed attempt/role/support leg/frame/view -> selected role-neutral 2D pose observation -> versioned metric math -> status/provenance/limitation -> Flutter result card`

The V1 video upload and pose-coverage diagnostic remains independent and
unchanged. V2A is additive. A pure internal Python function evaluates an
already prepared reviewed observation contract but is deliberately not exposed
through OpenAPI because client-supplied landmarks could spoof model provenance.
The public multipart video endpoint verifies the
reviewed start/end/angle frame timestamps against the source timebase, runs
pose inference only on the human-selected source frame and then applies the
same metric contract. It stops decoding after that selected frame and does not
use the benchmark 10 FPS plan. Flutter has a typed reviewed-request HTTP
service, but the end-user frame/person selection UX is not yet connected.
Source image width/height is mandatory for the pose observation. Normalized
landmarks are converted to image-pixel coordinates for angle math, preventing
frame aspect ratio from distorting projected geometry; overlay coordinates
remain normalized for Flutter rendering.

### Manual Gates

- Attempt start/end use source frame indices and timestamps and a declared
  event-pair schema.
- A reviewer maps a neutral `Track A/B/...` observation to Tori. Detection order
  alone is never identity.
- A reviewer confirms left/right support leg.
- A reviewer selects the angle evaluation frame/event label.
- Projected angles become `reportable` only after near-planar view suitability
  and low camera roll are reviewed. Otherwise usable geometry is
  `review_required`.

### Metric Layer

- `UM-TIM-001`: measured video timebase plus separately retained human boundary
  source; method `reviewed-event-elapsed-time-1.0.0`.
- `UM-ANG-001`: shoulder/hip midpoint axis projected against image vertical;
  source-image pixel geometry; method
  `projected-trunk-inclination-1.0.0`; `model-estimated`.
- `UM-ANG-002`: human-confirmed support-side hip-knee-ankle image-plane angle;
  source-image pixel geometry; method `projected-knee-angle-1.0.0`;
  `model-estimated`.

Missing landmarks, non-finite coordinates and degenerate geometry fail closed
to `withheld`. A withheld metric contains no value, descriptive finding or
overlay. Model landmark visibility is retained only under its own semantic
label and is not presented as pose accuracy.

The serialized BLUE layer is fail-closed: every coordinate must be finite and
inside normalized image space `[0, 1]`, labels must be non-blank, and each
metric accepts only its exact versioned primitive order and point count. The
Flutter service also binds a validated response back to every reviewed request
gate before presentation, so an internally consistent but stale or crossed
response cannot be rendered for another reviewed attempt.

### Observation and Identity Boundary

Timestamped pose observations remain frame-local and `model-estimated`.
Track association is a separate `AI-inferred` layer with explicit
`associated`, `review_required` and `withheld` states plus crossing, occlusion,
disappearance/reappearance and detection-order-change events. Tori/Uke role
confirmation remains a separate human gate.

### Result Presentation

Flutter validates the exact V2A metric set and rejects promoted provenance,
automatic identity/phase capability, 3D, kinetics or normative coaching. The
blue layer contains only trunk/support-leg projected geometry and angle labels.
Until a dedicated human-review selection UI is approved and connected, this
result card and service remain prepared integration components rather than an
automatic path from the existing V1 Analyze action.

### Human Ground Truth

The existing deterministic 100-timestamp fast-screening subset can be decoded
to review frames without pose inference. Human labels and model detection
counts remain separate. The evaluator computes conditional coverage such as
`P(two detected | at least two judoka actually visible)` only after complete
human labels exist. Empty templates are not ground truth.

Annotation schema `1.1.0` binds the draft and completed set to both the source
video SHA-256 and screening-artifact SHA-256. It preserves the selection method,
requires every reviewed frame/boundary to match the source timebase, prevents
preparation from overwriting an existing draft and provides a read-only
multi-issue readiness report without filling null labels. Artifact evaluation
fails closed unless video identity/metadata, both hashes and the exact shared
frame/timestamp subset align. Sample positions and canonical review-image paths
are preserved into the completed set; each path must encode the matching sample,
source frame and source timestamp so swapped review rows fail validation.
An optional dependency-free CSV round trip exposes only per-frame human-label
entry while treating sample/frame/time/image cells as immutable evidence. It
writes a new validated draft, refuses overwrite and preserves blank values as
incomplete rather than negative labels.
Integer evidence fields at this boundary are strict: booleans and floating-point
values cannot be coerced into frame indices, timestamps or person counts.
Path-based readiness schema `1.1.0` additionally requires every review JPEG to
exist, decode successfully and match source-video dimensions before reporting
that a completed draft can be finalized. Conditional artifact evaluation calls
this same path gate before finalization, so an in-memory model cannot bypass
review-asset readiness.
The readiness report validates its own count, status, finalization and asset
partition invariants when serialized or reloaded; a tampered readiness flag is
not trusted.

Detection evaluation schema `1.2.0` retains the overall conditional rates and
the broad occlusion/crossing slices, and adds four mutually exclusive strata:
occlusion only, crossing only, both, and neither. Additive counts in those four
strata must exactly partition the all-frame metrics. It explicitly declares
that coverage is not confidence, pose accuracy or athlete identity evaluation.

Neutral Track A/B evaluation remains timestamped and role-free. Its reference
contract rejects non-finite geometry/confidence, unknown events and conflicting
frame timebases, and reports one-to-one collisions where two human subjects are
assigned the same track or frame-local detection. Switch/collision results are
evaluation diagnostics only and do not authorize automatic Tori/Uke identity.
Evaluation rows and reports explicitly separate `human-reviewed` references
from `AI-inferred` predicted track associations.


## JM-DEC-023 ? Event-Scoped Technique Role Architecture

Video Analysis uses attempt-stable neutral subject identity and event-scoped
technique roles.

Subjects remain role-neutral (`subject-1`, `subject-2`, or validated neutral
tracks). Technique semantics belong to events.

This allows one attempt to represent:

- a single attack,
- repeated/follow-up attacks,
- combinations,
- attack followed by counter-attack,
- different technique actors within the same attempt.

The canonical relationship is:

`event -> actor subject -> target subject -> technique/event role`

rather than:

`subject -> permanent Tori/Uke role`.

Belt color, judogi color, screen side and detection order are not identity
rules.

Automatic event-role inference remains unavailable until separately validated.



## JM-DEC-024 ? Close-Contact Detection Architecture

The current single-camera chain retains RTMPose-M as the pose baseline.

The first optimization target is the upstream person detector/proposal layer
for two-judoka close-contact scenes.

Architecture remains:

`person proposals -> RTMPose-M pose estimation -> validated neutral subjects`

Close-contact detector improvement must not silently alter scientific
provenance or upgrade pose, identity or biomechanics claims.



## Multi-Person Evidence Capability Gate

Single Attempt Video Analysis now explicitly separates:

- single-subject evidence that may remain usable, and
- interaction evidence that requires reliable detection of both judoka.

Multi-person evidence status is represented in the existing V2A capability
contract rather than in a parallel analysis system.

Insufficient multi-person evidence must not silently promote interaction,
opponent-relative, Tori/Uke-relative, grip, distance, counter-attack, or other
two-subject metrics to reportable status.



## Single Attempt V2A Response Multi-Person Gate

The real Single Attempt V2A response now exposes multi-person evidence
sufficiency through the existing capability contract.

This allows clients to distinguish:

- currently available single-subject analysis, from
- two-subject interaction analysis that must remain unavailable or
  review-gated when multi-person evidence is insufficient.

The gate is part of the existing V2A response architecture and does not create
a parallel analysis pipeline.



## Boundary-Normalized Landmark Reporting Gate

Single Attempt V2A now carries explicit provenance when model-estimated
landmarks require clipping to the normalized image boundary.

A projected metric that depends on any boundary-normalized landmark cannot
automatically reach `reportable` status.

The metric may remain available as `review_required` when its geometry and
confidence otherwise exist.

This gate is metric-specific: an affected landmark must not downgrade an
unrelated metric whose required landmarks were not boundary-normalized.



## UM-ANG-003 ? Attacking-Leg Knee Angle

Single Attempt V2A now supports a fourth Level 1 metric:

`UM-ANG-003 ? Projected attacking-leg knee angle`

Architecture:

`human-confirmed attacking leg`
`-> Tori pose observation`
`-> attacking-side hip/knee/ankle`
`-> image-plane knee-angle method`
`-> metric-specific reporting gates`

The attacking leg must not be inferred from support-leg complement, belt color,
judogi color, detection order or screen position.

When attacking-leg classification is unavailable, the metric fails closed as
`withheld`.

The value remains a projected 2D angle and must not be interpreted as a true
3D anatomical knee angle, load, moment or injury-risk measure.

