# Judo Mind Project Status

## Document Information

Project:

Judo Mind Super App

Platform:

Flutter Mobile Application + Python AI Services

Development Path:

D:\projects\judo_mind

Current Version:

v0.15

Last Updated:

2026-08-08

Development Stage:

Uchi Mata Reference Completion + Scientific AI Biomechanics Foundation

Status:

Active Development

---

# Project Identity

Judo Mind is evolving from a mobile application into a global digital Judo ecosystem.

Vision:

Train Your Body, Master Your Mind.

Strategic Direction:

Operating System for World Judo

Target ecosystem:

- Athletes
- Coaches
- Clubs
- Federations
- Fans
- Researchers
- Administrators

---

# Official Product Architecture

Judo Mind consists of 18 official modules:

1. Home
2. Techniques
3. Sensi Bot
4. Sensi Bet
5. Monitoring
6. Judo Cast
7. Athlete Profile
8. Training Center
9. Champions Hub
10. Competitions & Challenges
11. News
12. Store & Subscription
13. Club Management
14. Coach Forum
15. Online Courses
16. Country Judo History
17. Administration & System Settings
18. AI Training Plan Intelligence

---

# Development Foundation

Completed:

✅ Flutter configured

✅ VS Code development environment

✅ Android physical-device workflow

✅ Git version control

✅ Project migrated to D drive

✅ Provider architecture

✅ Dependency injection foundation

✅ Repository architecture

✅ Local data-source architecture

✅ Feature-based architecture preparation

✅ Documentation architecture

---

# Documentation System

Completed:

✅ AGENTS.md repository instruction file

✅ AI_DEVELOPMENT_RULES.md

✅ ARCHITECTURE.md

✅ CHANGELOG.md

✅ DECISION_LOG.md

✅ PROJECT_STATUS.md

✅ PRODUCT_REQUIREMENTS.md

Documentation synchronization is mandatory for all major product and architecture changes.

The root `AGENTS.md` now provides the operational entry point for future AI-assisted work. It requires review of the approved reference documents, preservation of existing user work, documentation synchronization, scientific data classification, explicit approval before destructive Git operations or push, and compliance with the current 18-module Flutter and Python AI Engine architecture.

---

# Design System Status

Judo Mind Design System 1.0 foundation is implemented.

Completed:

✅ Design Tokens

✅ Global Color System

✅ Global Spacing System

✅ Global Radius System

✅ Typography System

✅ Global Theme

✅ Core UI Components

✅ Judo App Bar

✅ Centralized JudoIcons registry

✅ Standard JudoIcon component

✅ Custom Illustration infrastructure

✅ Selective Dashboard illustration system

Current visual direction:

- Dark professional theme
- Blue intelligence accent
- Gold professional/premium accent
- Green performance accent
- Centralized icon language
- Custom Judo Mind visual identity

---

# Techniques Module

Status:

Active Development

Reference Technique:

Uchi Mata

Objective:

Complete Uchi Mata as the approved technical, educational, visual, biomechanical and AI architecture for all 67 official Judo techniques.

Implemented:

✅ Technique List

✅ Technique Cards

✅ Search

✅ Category Filters

✅ Difficulty Filters

✅ Filter Bottom Sheet

✅ Technique Model

✅ Technique Bundle Architecture

✅ Repository Foundation

✅ Local Data Source

✅ Technique Detail Architecture

✅ Technique Dashboard

✅ Technique Bottom Sheet Navigation

✅ Technique Section Router

✅ Modular Technique Sections

✅ Professional Media Model

✅ Media Resolver

✅ Media Library Foundation

✅ Quiz Foundation

✅ Sources

✅ Localization Foundation

---

# Uchi Mata Reference Technique

Status:

Active Reference Implementation

Completed:

✅ Technique identity

✅ Hero Section

✅ Compact Learning Dashboard

✅ Technical information architecture

✅ Media architecture

✅ Quiz

✅ Sources

✅ Training entry

✅ Competition entry

✅ Sensi Bot / AI entry architecture

✅ Three-Layer Visual Learning architecture

✅ Shadow Training visual architecture

✅ Conditioning visual architecture

✅ Biomechanics visual architecture

✅ AI video selection

✅ Video recording entry

✅ Video preview

✅ Camera-angle selection

✅ Scientific disclaimer

✅ AI analysis preparation flow

---

# Three-Layer Visual Learning System

Status:

Architecture Implemented

Approved visual layers:

Blue:

Movement / Footwork / Body Motion

Gold:

Grip / Pull / Upper-Body Control

Green:

Force / Balance / Center of Gravity / Biomechanics

Current implementation:

✅ Reusable visual-learning data model

✅ Layer visibility controls

✅ Playback control

✅ Playback speed control

✅ Uchi Mata reference animation prototype

✅ Technical Execution sequence

✅ Biomechanics sequence

✅ Shadow Training sequence

✅ Strength & Conditioning sequence

Current limitation:

The current CustomPainter representation is an instructional prototype.

It is not the final biomechanical visualization quality target.

---

# AI Fight Intelligence 360

Status:

Active Development

Objective:

Analyze real Judo training and competition video with practical technical, tactical and biomechanical intelligence.

Flutter foundation completed:

✅ Video picker

✅ Video recording

✅ Video preview

✅ Video metadata

✅ Camera-angle selection

✅ Scientific disclaimer

✅ AI analysis entry

✅ Analyze My Uchi Mata routing

---

# Python AI Engine

Status:

Operational Development Foundation

Location:

ai_engine/

Computer Vision environment:

ai_engine/.venv

Biomechanics environment:

ai_engine/.biomech_venv

Completed:

✅ Python 3.12 development environment

✅ FastAPI backend foundation

✅ Uvicorn server

✅ Health endpoint

✅ Video upload endpoint foundation

✅ OpenCV

✅ MediaPipe

✅ RTMLib

✅ ONNX Runtime

✅ RTMPose

✅ RTMO evaluation

✅ OpenSim 4.6

---

# AI Pose Benchmark

Reference Input:

Same real Judo competition video

Duration:

53.89 seconds

Resolution:

1306 × 720

Source FPS:

30.03

Analysis sample:

540 frames at approximately 10 FPS

## Results

| Engine | At Least One Athlete | Two Athletes |
|---|---:|---:|
| MediaPipe Heavy | 99.63% | 31.48% |
| RTMPose-M | 97.04% | 48.33% |
| RTMPose-M + PoseTracker | 96.85% | 46.85% |
| RTMO-M | 40.56% | 8.15% |

Current baseline:

RTMPose-M

Reason:

RTMPose-M currently provides the best two-athlete detection result on the reference Judo video.

Important:

48.33% two-athlete detection is not considered production quality.

Generic pose estimation alone is not sufficient for Judo Mind.

---

# Scientific Biomechanics Architecture

Status:

Foundation Approved and Started

Architecture Decision:

JM-DEC-017 and JM-DEC-018

Core scientific direction:

Video

↓

Multi-Person Pose Estimation

↓

Tori / Uke Identity

↓

Camera Calibration

↓

Multi-View 3D Reconstruction

↓

OpenSim

↓

Judo-Specific Biomechanics

↓

AI Fight Intelligence

---

# OpenSim Foundation

Status:

Operational

Installed:

OpenSim 4.6

Environment:

ai_engine/.biomech_venv

Validation:

✅ Python import successful

✅ OpenSim Model initialization successful

Verified output:

Judo Mind OpenSim Engine: READY

Purpose:

- Musculoskeletal modeling
- Joint kinematics
- Joint angles
- Segment orientation
- Center-of-mass calculations
- Inverse kinematics
- Inverse dynamics when scientifically valid
- Joint moments and power when supported
- Future musculoskeletal simulation

---

# Biomechanics Quality Levels

## Standard Analysis

Input:

Single uploaded training or competition video

Classification:

Estimated

Targets:

- Technique recognition
- Phase analysis
- Technical feedback
- Tactical feedback
- Estimated movement metrics

---

## Advanced Biomechanics

Input:

Two or more synchronized and calibrated cameras

Classification:

3D Model-Based Analysis

Targets:

- Multi-view 3D reconstruction
- Joint kinematics
- Center-of-mass trajectory
- Segment orientation
- Tori / Uke interaction
- Technique-specific biomechanics

---

## Research / Validation

Possible integration:

- Marker-based Motion Capture
- Force Plates
- EMG
- IMU sensors
- Laboratory systems

Purpose:

Scientific validation of Judo Mind algorithms.

---

# Stereo Calibration Cycle Closure — 2026-08-07

Status:

Closed — current stereo extrinsic scientifically rejected

Scope:

The approximately 48-hour test cycle using the current two-phone video pair is complete. No further calibration, synchronization or geometry tests are to be run on those two videos.

Confirmed evidence:

- Camera 101 intrinsic calibration: `excellent`, RMS 0.4702348 px.
- Camera 102 intrinsic calibration: `good`, RMS 0.5232957 px.
- Camera orientations are confirmed as camera 101 `rotate180` and camera 102 `clockwise`.
- Applying the geometric +0.55 s candidate correction did not solve the stereo geometry.
- Stereo RMS worsened from the previously recorded 39.26 px result to 48.2750333 px.
- Median epipolar error is 55.4328918 px.
- Final stereo quality is `review_required`.

Scientific disposition:

- The current stereo extrinsic is rejected.
- It must not enter user-facing 3D reconstruction, biomechanics or OpenSim processing.
- The strong intrinsic results do not make the cross-camera extrinsic valid.
- A simple synchronization correction no longer explains the failure.
- Stabilization/EIS/OIS changing the effective virtual camera is a leading hypothesis only; it is not a confirmed cause.

Implemented safeguard:

- Multi-view reconstruction now requires a sealed validated-calibration context.
- Missing evidence and `review_required` reports fail closed.
- `usable_for_3d_validation` is limited to offline validation and cannot authorize user-facing scientific 3D.
- Calibration approval alone is necessary but not sufficient for OpenSim; identity, motion, reconstruction and anatomical-quality gates remain required.

---

# Scientific Integrity Rule

Judo Mind must distinguish:

- Measured
- Reconstructed
- Estimated
- AI-Inferred

Estimated physical quantities must never be presented as direct measurements.

Examples:

Force Plate GRF:

Measured

Video-derived GRF:

Estimated

EMG muscle activity:

Measured

OpenSim-derived activation:

Model Estimated

---

# Single-Camera Uchi Mata AI Analysis v1

## Vertical Slice 1: Pose Detection Summary

Status:

Implemented, automated-test validated and physical-device end-to-end validated with a new, explicitly single-camera Uchi Mata competition clip on 2026-08-07.

Implemented flow:

1. Flutter selects or records a video and records the camera view.
2. Flutter uploads the video to `POST /v1/analysis/single-camera/pose-summary` as multipart form data.
3. The recorded 2026-08-07 validation ran the MediaPipe Pose Landmarker Heavy baseline with a requested 10 FPS target and the then-current integer-stride sampler. The current uncommitted worktree uses the timestamp-based replacement described below.
4. Python returns the versioned `1.0.0` single-camera contract.
5. Flutter parses the contract, enforces the single-camera capability boundary, and displays pose coverage plus scientific limitations.

Scientific classification:

- Video resolution, duration, frame count and source FPS: `measured` container/video metadata.
- Pose visibility coverage: `model-estimated`.
- Coverage rate is not a scientific or biomechanical confidence score.
- Persistent Tori/Uke identity: not available.
- Kuzushi/Tsukuri/Kake phase detection: not available.
- Measured or reconstructed 3D: not available.
- Real force, real torque and laboratory-grade biomechanics: not available.

Safeguards:

- The API declares all unavailable capabilities as `false` and includes explicit limitations.
- Flutter rejects a response that claims identity, phase detection, 3D reconstruction, force or torque inside this single-camera contract.
- The result screen labels the current pose engine as experimental.
- The former ambiguous `3D` badge on the educational Biomechanics dashboard card is no longer shown.
- Local cleartext HTTP is enabled only in the Android debug manifest; production transport must use HTTPS.
- The AI Engine base URL can be set with `--dart-define=JUDO_MIND_AI_BASE_URL=...`; Android emulator development defaults to `http://10.0.2.2:8000`.

Validation:

- Two synthetic, video-free Python API tests pass.
- Three Flutter tests pass for parsing/provenance, multipart request wiring and result rendering.
- `flutter analyze` reports no diagnostic attributable to the new vertical-slice code; 20 existing repository warnings/information diagnostics remain outside this scope.
- Physical Android validation passed through the complete Video -> Flutter multipart upload -> FastAPI -> MediaPipe Pose Landmarker Heavy -> versioned `1.0.0` JSON -> Flutter parsing -> Result Card path.
- The real validation clip was 640x1136, 25 FPS, 593 source frames and 23.72 seconds long; the engine analyzed 297 sampled frames.
- The historical 297-frame result is approximately 12.5 sampled frames per second because the then-current integer-stride sampler rounded 25/10 to a stride of 2. The current worktree corrects that implementation issue, but real-video revalidation remains blocked pending a new explicit single-camera input.
- The displayed model-estimated pose coverage was 97% for at least one pose and 7% for two poses. These rates are diagnostic coverage only, not identity or biomechanics confidence.
- The final API request returned HTTP 200, all five scientific limitations were rendered, and no affirmative identity, phase, 3D, force or torque result was displayed.
- The temporary backend upload existed only during processing and the upload directory was empty after the response.
- Local CPU processing took approximately 4 minutes 40 seconds for this clip, confirming that the current local engine is a development baseline and remains too slow for production.
- No current or historical Stereo calibration video was processed or modified.

---

# Uchi Mata Scientific Metrics Specification v1

Status:

Official architecture and scientific specification approved; implementation not started.

Recorded on:

2026-08-08

Completed in this specification stage:

- Defined Fight Intelligence 360 Level 1 Single-Camera AI, Level 2 Multi-Camera 3D and Level 3 Professional/Federation/Laboratory analysis.
- Preserved every JM-DEC-018 calibration and provenance safeguard.
- Defined a versioned Uchi Mata metric registry with required role, phase/event, landmarks or sensors, formula, unit, level, provenance, confidence, source, allowed interpretation and prohibited interpretation.
- Defined the Level 1 boundary as projected 2D model estimates and AI inference, never true/reconstructed 3D or measured kinetics.
- Preserved Level 2 as the official path to reconstructed 3D after synchronization, calibration, orientation, cross-camera identity, correspondence, triangulation and quality gates.
- Defined Level 3 as the validation and advanced laboratory path for high-speed motion capture, force plates, optional IMUs/EMG and OpenSim-supported modeling.
- Recorded source-specific phase definitions without forcing them into the canonical Preparation/Kuzushi/Tsukuri/Kake/Flight/Landing/Transition sequence.
- Defined Interactive 3D/360 as virtual-camera viewing of valid reconstruction, not 360-camera capture.
- Defined the coordinated result UX: AI Sensi, annotated video, voice coaching, scientific report and conditional 3D/360.
- Selected execution duration, projected trunk inclination and projected support-leg knee angle as the first three metrics recommended after stable Tori identity and an event-annotation protocol exist.

Scientific source review:

- DOI `10.3390/jfmk10040378`
- DOI `10.34518/rjsp.16.0_10`
- DOI `10.51979/KSSLS.2013.12.54.1073`
- DOI `10.5103/KJSB.2002.12.1.063`
- DOI `10.11214/budo.50.S_73`

No source-code implementation or new video analysis was performed in this stage. No old Stereo video was tested or modified.

---

# Night Shift 01: Pose Reliability Foundation

Status:

Implemented and unit-tested in the current uncommitted worktree; real-video
benchmark blocked pending an explicit single-camera Uchi Mata test video.

Completed:

- Audited the real MediaPipe Heavy, RTMO-M, RTMPose-M diagnostic and RTMLib
  PoseTracker paths in `docs/AI_POSE_ENGINE_AUDIT.md`.
- Confirmed that the current FastAPI vertical slice runs MediaPipe Heavy, while
  `ai_engine/rtmpose_engine.py` actually runs RTMO-M despite its filename.
- Replaced integer-stride sampling in the three existing single-camera 2D paths
  with a shared deterministic nearest-timestamp sampling plan.
- Confirmed by unit test that 25 FPS to 10 FPS selects 10 frames per nominal
  second and that the prior 593-frame source shape maps to 238 planned frames.
- Added a non-production multi-engine benchmark harness for comparable,
  versioned JSON and human-readable MediaPipe Heavy, RTMPose-M and RTMO-M
  coverage/runtime results.
- Added a role-neutral identity-tracking contract and synthetic evaluation for
  identity switches, annotated crossings, occlusion and reappearance.
- Preserved `model-estimated` pose detections and `AI-inferred` tracking
  associations; no Tori/Uke classifier or production identity claim exists.

Validation:

- 20 focused Python tests pass for the sampler, benchmark harness, neutral
  tracking contract and existing versioned API behavior.
- Python syntax compilation passes for the changed and added modules.
- Temporary-upload cleanup is covered for both successful analysis and engine
  failure.
- A synthetic capture/landmarker integration test confirms the exact 25 FPS to
  10 FPS frame indices and timestamps used by `JudoPoseEngine`.
- `git diff --check` passes.
- No Flutter source changed, so `flutter analyze` is not required for this
  implementation stage.

Blocked:

- `BLOCKED — TEST VIDEO REQUIRED`: the upload directory is empty and the only
  project-runtime videos are forbidden closed Stereo/Calibration inputs. No
  real engine benchmark or corrected-sampler rerun was performed.

Scientific gate:

- No phase, trunk/knee/COM metric, force, torque, 3D, OpenSim or coaching output
  was added. Upstream detection and identity remain below that gate.

Fallback audits:

- Added `docs/NIGHT_SHIFT_01_AUDIT.md` with prioritized single-camera test gaps,
  exact classification of the 20 pre-existing Dart analyzer diagnostics, a
  read-only audit of all 17 official product modules and categorized AI pipeline
  technical debt.
- Confirmed that, before JM-DEC-020 approval, the official architecture defined
  17 modules and the dashboard contained two non-official standalone tiles
  (`Medical Support` and `Nutrition`). JM-DEC-020 now adds AI Training Plan
  Intelligence as Module 18; it does not retroactively approve either tile.
- Direct `flutter analyze --no-pub` stalled without output; `dart analyze
  --format machine` returned the 20 known diagnostics and then hit a denied
  user-level telemetry-session write outside the workspace. No Flutter source
  or security setting was changed.
- A broad Python compilation attempt entered the ignored `.venv` and exposed an
  invalid character in a packaged MediaPipe test file. Targeted project-source
  compilation passes; no third-party environment file was modified.

---

# Module 18 Formalization

Status:

Approved product and architecture definition; no UI/backend implementation

Module:

AI Training Plan Intelligence

Current scope:

- Evaluate athlete- or coach-provided plans against training period,
  competition timing, athlete context, strength and conditioning, physiology,
  recovery/load principles, Judo requirements and primary scientific evidence.
- Identify supported, questionable, risky and inconsistent elements.
- Explain reasoning, cite evidence/provenance and propose justified alternatives.
- Preserve uncertainty and avoid a universal-correct-plan claim.
- Keep sport-performance guidance separate from medical diagnosis.

Not implemented:

- Flutter module UI
- Backend ingestion or analysis service
- Automated plan generation or modification
- Medical diagnosis, treatment or safety claims

---

# Autonomous Development Shift 01 Reliability Status

Status:

Implementation and offline validation complete; real-video and Flutter-tool
validation blocked

Implemented:

- Hardened deterministic sampling for representative 24/25/30/50/60 FPS,
  non-integer rates, short clips, boundary frames and unique millisecond
  timestamps.
- Kept reported timestamps source-relative while allocating strictly increasing
  internal MediaPipe VIDEO timestamps when one landmarker processes multiple
  videos.
- Stabilized successful/failed benchmark JSON metric schemas and added offline
  tests for no-, one- and two-pose coverage, missing dependencies, engine
  failure, timing and serialization.
- Expanded role-neutral synthetic tracking evaluation for detection-order swap,
  one-person intervals, occlusion/reappearance, confidence availability and
  explicit termination/reinitialization.
- Closed temporary-upload lifecycle gaps on pre-processing validation errors.
- Strengthened the Flutter parser boundary for schema/status, provenance,
  confidence, capability flags, coverage consistency and required limitations;
  added explicit HTTP 404 endpoint/version diagnostics.

Validation:

- 37 focused Python tests pass.
- Dart formatter parses all three changed Dart/test files with zero formatting
  changes after formatting the new test additions.
- `flutter test --no-pub test/single_camera_pose_summary_test.dart` and targeted
  `dart analyze` both timed out without diagnostics in the current environment.
  Existing long-running Dart processes were not terminated or modified.
- `BLOCKED — TEST VIDEO REQUIRED`: `ai_engine/runtime/uploads/` is empty. No
  corrected-sampler real benchmark was run, and historical real two-person
  coverage remains approximately 7%.
- No Stereo/Multiview/Calibration media was processed or modified.

Scientific gate:

- No Tori/Uke role classification, technique phase, COM coaching, 3D, force,
  torque, joint moment/power, OpenSim or automatic AI Sensi judgment was added.

---

# Current Main Development Task

## Single-Camera Pose Benchmark Performance Diagnosis

Date: 2026-08-08

Status: Diagnosis, optimized real FAST SCREENING and benchmark artifact
validation complete.

- Authorized source metadata: 110.72 s, 640 x 360, 25 FPS, 2,768 native frames.
- Deterministic 10 FPS plan: 1,108 samples shared exactly across engines.
- MediaPipe Heavy completed 1,108/1,108 in 1,041.077 s on CPU.
- RTMPose-M completed 1,108/1,108 in 8,658.745 s on CPU and is the confirmed
  cause of the multi-hour execution.
- The 100-timestamp content-neutral full-span subset was matched exactly against
  all three engines.
- MediaPipe Heavy was reused from the complete artifact: 100/100 processed,
  91% >=1-person coverage and 25% >=2-person coverage.
- RTMPose-M was reused from the complete artifact: 100/100 processed,
  95% >=1-person coverage and 46% >=2-person coverage.
- Only RTMO-M ran new inference: 100/100 processed, 86% >=1-person coverage and
  42% >=2-person coverage in 677.966 processing seconds on CPU.
- No CUDA/GPU execution occurred. No download or dependency installation was
  performed.
- Per-engine progress, timeout/isolation, checkpointing, cancellation, device
  reporting and stage timing are now implemented.
- Total new engine initialization plus processing was 681.351 seconds; the
  complete RTMO command wall time was 693.4 seconds. MediaPipe and RTMPose added
  zero new inference.
- Raw cross-model confidence scores were not ranked, and a common keypoint
  completeness value was unavailable from the stored artifact contracts.
- This screening makes no pose-accuracy, identity, phase, technique or
  biomechanics claim because no ground-truth annotations were used.
- Next operational candidates are RTMPose-M and RTMO-M for a small,
  role-neutral Track A/B and reviewed annotation evaluation; this is not a
  scientific accuracy ranking.
- Benchmark sampling rate remains an evaluation setting, not the scientific
  temporal resolution for future biomechanics.

---

## Fight Intelligence 360 Video Analysis Modes

Decision:

JM-DEC-021

Status:

Approved architecture and product requirement; bounded Single-Attempt V2A
foundation active, broader mode orchestration unimplemented

The Analyze experience now has three formally distinct future modes:

1. Technique Analysis - One Attempt
2. Training / Drill Analysis - Multiple Repetitions
3. Competition Analysis - Full Match

Architecture boundary:

- One Technique Analysis window equals one primary attempt with useful context
  immediately before and after it; no arbitrary universal duration is approved.
- Repeated drill attempts require event segmentation and independent
  per-attempt analysis before comparison or aggregation.
- Full Match Analysis requires temporal event detection, attack segmentation,
  per-attempt analysis and a separate match-level tactical aggregation layer.
- Multiple unsegmented attempts or attacks must never be blended into one
  technique or biomechanics result.
- Fatigue must not be inferred from repetition change without validated
  evidence.

Scientific relationship:

- These modes describe temporal/user-task scope and do not replace the
  independent Level 1/2/3 scientific architecture.
- Every mode retains measured, reconstructed, model-estimated or AI-inferred
  provenance and all existing identity, phase, 3D, kinetics and OpenSim gates.
- The Pose Engine Benchmark is detection/reliability/performance evaluation, not
  Technique Analysis.
- Its timestamp-based 10 FPS target is not a universal biomechanics sampling
  rate. Future metrics require source timestamps and a validated,
  metric-appropriate temporal resolution.

Future result architecture remains AI Sensi + Annotated Video + Voice Coaching
+ Scientific Report + Interactive 3D/360 only when scientifically available.

Not implemented:

- Automatic event or attempt segmentation
- Technique classification or phase judgment for these modes
- Drill comparison or fatigue inference
- Full-match timeline and tactical aggregation
- Flutter mode-selection and reviewed-input UX
- End-to-end upload-to-V2A orchestration

---

## Single-Attempt Uchi Mata V2A Foundation

Date:

2026-08-08

Decision:

JM-DEC-022

Status:

Software contract/math/UI foundation complete; real reviewed attempt pending

Implemented:

- Versioned `2.0.0` request/response contracts for attempt boundaries,
  human-confirmed Tori, human-confirmed support leg, reviewed angle frame,
  camera suitability, metric state, time/frame, unit, provenance, model
  visibility semantics, limitations and blue overlay geometry.
- `UM-TIM-001`, `UM-ANG-001` and `UM-ANG-002` math with fail-closed missing,
  invalid, non-finite and degenerate behavior. Normalized pose landmarks are
  converted with mandatory source width/height to aspect-correct image-pixel
  coordinates before projected-angle math.
- Internal pure V2A metric evaluation plus a public multipart video route that
  validates reviewed frame timestamps against source metadata and infers only
  the selected source frame. Client-supplied pose landmarks are not a public
  input; no identity, support leg or phase is inferred.
- Adapter from one human-selected frame-local MediaPipe pose to the role-neutral
  V2A observation contract.
- Timestamped neutral observation, association uncertainty/withholding and
  crossing/occlusion/disappearance/reappearance event contracts.
- Versioned human annotation schema and evaluator for conditional detection
  coverage after human labels exist.
- Ground-truth schema `1.1.0` now preserves screening-artifact/video hashes and
  subset provenance, validates the source timebase, refuses accidental draft
  overwrite and exposes a read-only multi-issue readiness report. It also
  preserves sample/image references into the completed set and rejects an image
  path that does not encode its exact sample, source frame and timestamp.
- Added an offline CSV export/import workflow for the 100 per-frame labels. It
  locks evidence columns, preserves blanks as incomplete, validates the merged
  draft and refuses to overwrite either CSV or JSON output.
- Frame/timestamp/sample/video-dimension/person-count evidence now rejects
  boolean or floating-point coercion where the contract requires an integer.
- Role-neutral subject references reject Tori/Uke role tokens even when they are
  embedded in a longer identifier.
- Annotation manifest, CSV, merged-draft, readiness-report and evaluation-result
  writers use create-new semantics and preserve every existing output.
- Detection evaluation schema `1.2.0` verifies artifact/video/subset alignment
  and reports overall, broad occlusion/crossing and four mutually exclusive
  occlusion-only/crossing-only/both/neither strata. Their additive counts must
  partition the all-frame metrics; coverage is not confidence or pose accuracy.
- Flutter typed reviewed-request/HTTP service, V2A parser with a strict
  scientific boundary, three-metric result card and blue geometry painter.
- Flutter now rejects a response that is internally valid but does not match
  the current reviewed request's video, camera, attempt, neutral track,
  detection, support leg, angle frame/event or camera-suitability gates.
- BLUE geometry is now contract-bound to normalized in-frame coordinates and
  the exact approved primitive/point structure; out-of-frame, duplicate,
  reordered, blank-label or otherwise unexpected geometry fails closed in both
  Python and Flutter.
- English and Persian V2A result labels, with English fallback in other current
  generated locale classes.

Review preparation:

- Decoded the existing deterministic 100-timestamp benchmark subset into 100
  frames and four contact sheets under ignored runtime storage.
- Preserved the authorized source SHA-256 before/after extraction.
- Preparation now also fails if the screening artifact changes while review
  assets are being produced.
- Ran no pose inference and created no human labels; artifact status is
  `awaiting_human_annotation`.
- The live readiness check reports 0 complete and 100 incomplete frames, all
  five required reviewer fields missing, and
  `labels_inferred_or_defaulted=false`.
- Readiness schema `1.1.0` confirms all 100/100 review JPEGs are present,
  readable and exactly 640x360; missing/corrupt/wrong-dimension lists are empty.
- The conditional artifact evaluator now requires the same review-asset
  preflight before finalization; direct model validation cannot bypass it.
- Readiness reports self-validate complete/incomplete counts, sample positions,
  status/finalization equivalence and the missing/unreadable/readable asset
  partition; tampered readiness flags fail parsing.
- The live artifact-alignment preflight verifies the expected screening
  artifact SHA-256 and unchanged source-video SHA-256.

Neutral tracking hardening:

- Track A/B evaluation now requires source timestamps, rejects non-finite
  geometry/scores/confidence and conflicting frame timebases, restricts event
  tags and reports same-track/same-detection one-to-one collisions. Rows and
  reports fix reference provenance to `human-reviewed` and predictions to
  `AI-inferred`.
- These are synthetic/evaluation-only safeguards and do not claim real tracking
  accuracy or automatic Tori/Uke identity.

Validation:

- All 118 Python tests pass across V2A math/contracts/API, annotations, pose
  adapter, neutral tracking, benchmark controls and the existing V1 endpoint.
- 13 focused Flutter parser/widget/service and V1 regression tests pass.
- Targeted Dart static analysis of the complete V2A slice reports no issues.
- Full-project `flutter analyze --no-pub` reached its 244.1-second timeout
  without emitting a diagnostic; this is recorded as a tooling timeout, not a
  pass or a source failure.
- Synthetic tests prove software/math behavior only, not pose accuracy or
  scientific validity.
- Flutter source changed during the final integration audit. The earlier 13
  focused Flutter tests remain historical evidence for the preceding revision,
  not a validation of the final hardening change.
- A final repeat of the three focused Flutter test files emitted no output and
  timed out after 183.2 seconds. It is recorded as a tooling timeout, not a pass
  or source failure, and does not replace the earlier 13-test success.
- A later two-file V2A-only Flutter test attempt also emitted no output and
  timed out after 259.3 seconds. It is likewise not recorded as a pass or
  source failure; focused Python contract/API tests passed after the change.

Pending before a real coach-useful result:

- one human-reviewed single attempt with source start/end frame/timestamp and
  declared event pair;
- human-confirmed Tori and support leg;
- selected angle frame/event plus camera-view suitability and low-roll review;
- connection of reviewed frame/person selection UX to the prepared V2A video
  service and the existing Analyze screen;
- annotated real validation before any normative coaching.

---

## Judo Mind Scientific Biomechanics Foundation

Reference Technique:

Uchi Mata

Current objective:

Implement the approved Uchi Mata Scientific Metrics v1 incrementally within the three-level Fight Intelligence 360 boundary while preserving every validation gate required before 3D, kinetics or OpenSim use.

Current focus:

→ Persistent Tori / Uke identity and reviewed event annotation for Level 1

→ First three projected/temporal Level 1 metrics with provenance and confidence

→ Fail-closed calibration and synchronization architecture for Level 2

→ Cross-camera identity and 2D-to-3D landmark reconstruction

→ Level 3 reference-validation path and OpenSim-compatible motion data

---

# Current Technical Limitations

- Two-athlete detection is not yet production quality.
- Tori / Uke identity persistence is not implemented.
- Severe Judo occlusion remains unresolved.
- Low-level multi-view triangulation exists only as a guarded development foundation; production 3D reconstruction is not implemented or scientifically validated.
- The current two-phone stereo extrinsic is scientifically rejected and blocked from 3D, biomechanics and OpenSim use.
- OpenSim has not yet been connected to reconstructed Judo motion.
- Joint kinetics cannot be claimed from ordinary video as measured data.
- Local CPU AI processing is too slow for production.
- Production GPU infrastructure is not yet implemented.
- Judo-specific AI models are not yet trained.
- Scientific Judo validation dataset has not yet been created.

---

# Infrastructure Direction

Local CPU:

Development and Benchmarking

Production:

GPU-backed AI infrastructure

Flutter:

Capture + Interaction + Visualization

AI Backend:

Computer Vision + 3D Reconstruction + Biomechanics + Judo Intelligence

CMS / Backend:

Planned

---

# Development Roadmap

## Phase 1

Uchi Mata Reference Technique

Status:

Active

## Phase 2

Scientific Biomechanics + AI Fight Intelligence Foundation

Status:

Active

## Phase 3

Complete Technique Intelligence Database

Target:

67 official techniques

## Phase 4

Training Center

## Phase 5

Sensi Bot AI

## Phase 6

Athlete Profile + Monitoring

## Phase 7

Backend + CMS

## Phase 8

Administration Panel

---

# Git Status

Repository:

Active

Current Development:

Uchi Mata + AI Fight Intelligence + Scientific Biomechanics

Next Recommended Commit:

Scientific Biomechanics Foundation + OpenSim Architecture

---

# Documentation Synchronization

Every major change must update:

- ARCHITECTURE.md
- PROJECT_STATUS.md
- CHANGELOG.md
- DECISION_LOG.md
- PRODUCT_REQUIREMENTS.md

---

# Final Vision

Build the world's most complete digital Judo ecosystem combining:

- Judo technical knowledge
- Biomechanics
- Training science
- Artificial intelligence
- Athlete development
- Coaching intelligence
- Competition analysis
- Federation services
- Scientific validation
- Professional digital infrastructure

## Three-Camera Scientific Calibration Status - 2026-08-08

A new independent three-camera ChArUco session was validated.

### Current Gate Status

- Camera A intrinsic calibration: `PASS / excellent` - RMS `0.2046 px`
- Camera B intrinsic calibration: `PASS / excellent` - RMS `0.2782 px`
- Camera C intrinsic calibration: `PASS / excellent` - RMS `0.3195 px`
- A-B audio synchronization: `PASS / good`
- A-C audio synchronization: `PASS / good`
- A-B stereo extrinsic calibration: `FAIL / review_required`
- A-C stereo extrinsic calibration: `FAIL / review_required`
- Independent A-B geometry consistency: `FAIL`
  - Median translation deviation: `33.56 mm`
  - Median rotation deviation: `5.718 deg`
- Scientific 3D readiness: `BLOCKED`

### Scientific Boundary

The 2026-08-08 three-camera session must not be used for scientific 3D reconstruction or for 3D biomechanical, force, torque, moment, power or other spatial scientific claims.

The excellent intrinsic results remain valid as single-camera calibration evidence for their respective recording configurations. Passing intrinsic and audio-sync gates does not promote failed stereo geometry.

The failed extrinsic/geometry results are retained as validation evidence and must not be promoted to production/scientific stereo calibration.

The existing single-camera scientific-analysis pipeline remains unaffected.



## JM-DEC-023 ? Video Role Architecture Status

Status: `APPROVED / architecture`

The video-analysis identity model now separates:

- attempt-stable neutral subject identity; and
- event-scoped technique actor/target roles.

This architecture supports future competition sequences containing attack and
counter-attack without assigning one permanent Tori to the whole attempt.

Current Uchi Mata human-review state:

- reviewed attempt: `70.000-75.000 s`
- frames: `1750-1875`
- attempt boundary source: `human-selected`
- technique performer: human-confirmed for the selected event
- support leg: `right / human-confirmed`
- frame-label CSV exported
- 100-frame ground-truth annotation remains in progress

Automatic attack/counter-attack role inference remains unavailable.



## Human Annotation Progress ? Samples 000-024

- Ground-truth review source: `human-reviewed`
- Reviewed attempt: `70.000-75.000 s`
- Attempt frames: `1750-1875`
- Human-confirmed technique actor reference: `subject-2`
- Human-confirmed support leg: `right`
- Human frame annotation complete through sample `#024`
- Completed samples: `25 / 100`
- Remaining samples: `75 / 100`
- No missing labels were inferred or defaulted.
- Subject identity remains attempt-stable and technique roles remain event-scoped
  under `JM-DEC-023`.
- Belt color, judogi color, screen position and detection order remain prohibited
  as identity or technique-role rules.
- Current annotation artifact:
  `ai_engine/runtime/annotation_review/run01/annotation_frames_000_024_confirmed.json`



## Human Annotation Progress ? Samples 000-049

- Ground-truth review source: `human-reviewed`
- Reviewed attempt: `70.000-75.000 s`
- Attempt frames: `1750-1875`
- Human-confirmed technique actor reference: `subject-2`
- Human-confirmed support leg: `right`
- Human frame annotation complete through sample `#049`
- Completed samples: `50 / 100`
- Remaining samples: `50 / 100`
- No missing labels were inferred or defaulted.
- Subject identity remains attempt-stable and technique roles remain event-scoped
  under `JM-DEC-023`.
- Belt color, judogi color, screen position and detection order remain prohibited
  as identity or technique-role rules.
- Current annotation artifact:
  `ai_engine/runtime/annotation_review/run01/annotation_frames_000_049_confirmed.json`



## Human Annotation Progress ? Samples 000-074

- Ground-truth review source: `human-reviewed`
- Reviewed attempt: `70.000-75.000 s`
- Attempt frames: `1750-1875`
- Human-confirmed technique actor reference: `subject-2`
- Human-confirmed support leg: `right`
- Human frame annotation complete through sample `#074`
- Completed samples: `75 / 100`
- Remaining samples: `25 / 100`
- No missing labels were inferred or defaulted.
- Subject identity remains attempt-stable and technique roles remain event-scoped
  under `JM-DEC-023`.
- Belt color, judogi color, screen position and detection order remain prohibited
  as identity or technique-role rules.
- Current annotation artifact:
  `ai_engine/runtime/annotation_review/run01/annotation_frames_000_074_confirmed.json`



## Human Annotation Progress ? Samples 000-099

- Ground-truth human frame review: `COMPLETE`
- Reviewed samples: `100 / 100`
- Remaining human frame samples: `0 / 100`
- Reviewed attempt: `70.000-75.000 s`
- Attempt frames: `1750-1875`
- Attempt boundary source: `human-selected`
- Human-confirmed technique actor reference: `subject-2`
- Human-confirmed support leg: `right`
- Subject identity rem ains attempt-stable and technique roles remain event-scoped
  under `JM-DEC-023`.
- Belt color, judogi color, image position and detection order are not identity
  or role rules.
- No unreviewed frame label was inferred or defaulted.
- Current human-reviewed draft artifact:
  `ai_engine/runtime/annotation_review/run01/annotation_frames_000_099_confirmed.json`
- Finalization status: `PENDING FORMAL READINESS / FINALIZER GATE`
- `100/100 human-reviewed` must not yet be reported as finalized ground truth
  until the formal annotation finalizer passes.



## Uchi Mata Ground Truth Run 01 ? Complete

- Ground-truth status: `COMPLETE`
- Annotation type: `single_attempt_uchi_mata_ground_truth`
- Reviewed samples: `100 / 100`
- Reviewed attempt: `70.000-75.000 s`
- Attempt frames: `1750-1875`
- Reviewer reference: `reviewer-jm-human-01`
- Human-confirmed technique actor reference: `subject-2`
- Human-confirmed support leg: `right`
- Review assets validated: `100 / 100`
- Missing human fields: `0`
- Missing frame fields: `0`
- Labels inferred/defaulted: `false`
- Final readiness gate: `PASS`
- Finalizer status: `complete`
- Final artifact:
  `ai_engine/runtime/annotation_review/run01/uchi_mata_ground_truth_run01.json`
- Governing identity/role architecture: `JM-DEC-023`
- Subject identity remains attempt-stable.
- Technique actor/target roles remain event-scoped.
- Belt color, judogi color, screen side and detection order are not identity
  or technique-role rules.



## RTMPose-M Human Ground-Truth Detection Evaluation ? Run 01

- Evaluation schema: `1.2.0`
- Engine: `rtmpose-m`
- Human ground-truth frames: `100`
- Matched prediction frames: `100`
- Missing predictions: `0`
- Artifact alignment: `PASS`
- New inference performed: `NO`

### Overall Detection Coverage

- Frames with >=1 visible judoka: `96`
- Frames with >=1 model detection: `95`
- Conditional >=1-person detection coverage: `98.96%`
- Frames with >=2 visible judoka: `96`
- Frames with >=2 model detections: `46`
- Conditional two-person detection coverage: `47.92%`
- Detection-deficit frames: `50`
- Detection-surplus frames: `6`

### Conditional Two-Person Coverage

- Clear of occlusion and crossing: `18/21 = 85.71%`
- Occlusion present: `28/75 = 37.33%`
- Occlusion without crossing: `21/51 = 41.18%`
- Occlusion and crossing: `7/24 = 29.17%`
- Crossing present: `7/24 = 29.17%`
- Crossing without occlusion: no human-labelled samples in Run 01

### Current Technical Interpretation

RTMPose-M demonstrates strong ability to detect at least one judoka in this
reviewed video, but reliable two-judoka separation is not yet sufficient for
scientific multi-athlete analysis.

The principal observed failure mode is multi-person separation during physical
overlap, occlusion and crossing.

Clear-frame two-person detection is substantially stronger than contact-frame
performance, indicating that close-contact judo interaction is the current
detection bottleneck.

### Scientific Boundary

These results establish `detection coverage only`.

They do NOT establish:

- pose/keypoint accuracy
- Tori/Uke or athlete identity accuracy
- technique recognition accuracy
- phase recognition accuracy
- biomechanics accuracy
- 3D accuracy
- force, torque, moment, power or injury-risk validity

Evaluation artifact:
`ai_engine/runtime/annotation_review/run01/rtmpose_m_detection_ground_truth_evaluation_run01.json`



## Three-Engine Human Ground-Truth Detection Comparison ? Run 01

Three existing FAST SCREENING engine outputs were evaluated against the same
finalized 100-frame human-reviewed Uchi Mata Ground Truth Run 01.

No new model inference was performed.

### RTMPose-M

- >=1-person conditional coverage: `98.96%`
- two-person conditional coverage: `47.92%`
- clear two-person coverage: `85.71%`
- occlusion two-person coverage: `37.33%`
- occlusion + crossing two-person coverage: `29.17%`
- detection deficits: `50`
- detection surplus: `6`

### RTMO-M

- >=1-person conditional coverage: `89.58%`
- two-person conditional coverage: `43.75%`
- clear two-person coverage: `80.95%`
- occlusion two-person coverage: `33.33%`
- occlusion + crossing two-person coverage: `8.33%`
- detection deficits: `54`
- detection surplus: `0`

### MediaPipe-Heavy

- >=1-person conditional coverage: `94.79%`
- two-person conditional coverage: `26.04%`
- clear two-person coverage: `23.81%`
- occlusion two-person coverage: `26.67%`
- occlusion + crossing two-person coverage: `12.50%`
- detection deficits: `71`
- detection surplus: `0`

### Current Interpretation

`RTMPose-M` is the strongest current detection baseline among the three tested
engines for this human-reviewed Run 01.

Its advantage is especially important during combined occlusion/crossing,
which is a central failure mode in close-contact judo.

However, overall two-person coverage of `47.92%` remains insufficient for
reliable scientific multi-athlete analysis.

RTMPose-M also produced `6` detection-surplus frames, which require later
false-positive review.

### Scientific Boundary

This comparison evaluates detection coverage only.

It does not establish:

- keypoint / pose accuracy
- athlete identity accuracy
- Tori/Uke or event-role accuracy
- technique recognition
- phase recognition
- biomechanics validity
- 3D or kinetics validity

RTMPose-M is therefore recorded as the `current detection baseline`, not as a
validated scientific pose solution.



## RTMPose-M Failure-Frame Audit ? Run 01

- Ground-truth detection deficits: `50`
- Detection-surplus frames: `6`
- Deficit frames with exactly one detection for two visible judoka: `49 / 50`
- Complete detector dropout among deficit frames: `1 / 50`
- Deficits with occlusion present: `47 / 50`
- Deficits in clear frames: `3 / 50`
- Deficits with combined occlusion/crossing: `17 / 50`
- Surplus detections:
  - five frames with three detections for two visible judoka
  - one frame with four detections for two visible judoka

### Current Bottleneck

The dominant RTMPose-M failure mode is not general person-presence detection.

The dominant failure is failure to preserve/separate the second judoka during
close-contact interaction, especially when physical occlusion is present.

The next investigation therefore targets:

- second-person suppression or merging,
- close-contact multi-person proposals,
- occlusion handling,
- crossing/reappearance continuity,
- and the six surplus/false-positive candidate frames.

No new model inference was performed for this audit.

### Scientific Boundary

This audit classifies detection-count failures only.

It does not establish the cause inside the detector and does not establish
pose, keypoint, athlete-identity or biomechanics accuracy.



## JM-DEC-024 ? Close-Contact Detection Bottleneck Localized

Status: `DIAGNOSTIC COMPLETE / ENGINEERING TARGET IDENTIFIED`

- RTMPose-M reproduction diagnostic: `12/12 PASS`
- Original benchmark video used: `YES`
- Original YOLOX-M + RTMPose-M configuration reproduced: `YES`
- Production pipeline modified: `NO`
- Primary bottleneck: `person detection/proposal under close contact`
- Secondary bottleneck: `pose validity/filtering in a minority of cases`
- RTMPose-M pose baseline retained: `YES`
- Additional diagnostic chain: `STOPPED`
- Next work: one bounded detector-side improvement experiment

The project now returns from failure localization to implementation.



## Bounded Detector Score-Threshold Experiment ? Run 01

- Governing decision: `JM-DEC-024`
- Experiment type: bounded detector-side engineering test
- Baseline YOLOX score threshold: `0.70`
- Experimental score threshold: `0.50`
- NMS threshold held fixed: `0.45`
- RTMPose keypoint threshold held fixed: `0.30`
- Minimum qualifying keypoints held fixed: `8`
- Evaluated human-ground-truth frames: `100`
- Production code modified: `NO`

### Result

Baseline:
- two-person coverage: `47.92%`
- occlusion + crossing two-person coverage: `29.17%`
- detection deficits: `50`
- detection surplus: `6`

Score-threshold 0.50:
- two-person coverage: `47.92%`
- occlusion + crossing two-person coverage: `29.17%`
- detection deficits: `50`
- detection surplus: `6`

Pre-registered improvement gate: `FAIL`

### Decision

The detector score-threshold tuning branch is closed.

No sequential search over additional score thresholds is authorized from this
result.

RTMPose-M with the existing detector configuration remains the current
baseline.

The known limitation remains close-contact second-person detection.

The project returns to the main Video Analysis implementation path with this
limitation explicitly gated rather than hidden.



## Multi-Person Evidence Capability Gate

- Contract: `single_attempt_analysis_v2a`
- Contract tests: `PASS`
- New capability state:
  `multi_person_evidence_status`
- Current default:
  `insufficient`
- Multi-person interaction metrics reportable:
  `false`
- Human-confirmed Tori capability remains available.
- Human-confirmed support-leg capability remains available.
- Existing Uchi Mata V2A metric calculations are unchanged.
- No inference was performed for this contract update.
- Governing close-contact detection decision: `JM-DEC-024`

The current detection limitation does not automatically block valid
single-subject metrics.

Metrics that require reliable evidence from both judoka must not become
reportable while multi-person evidence is insufficient.



## Single Attempt V2A Response Multi-Person Gate

- Response integration status: `COMPLETE`
- API contract tests: `4/4 PASS`
- Response capability:
  `multi_person_evidence_status = insufficient`
- Response capability:
  `multi_person_interaction_metrics_reportable = false`
- Existing three V2A metrics remain unchanged.
- Missing-pose fail-closed behavior remains intact.
- Automatic Tori/Uke identity remains unavailable.
- Automatic phase detection remains unavailable.
- Current scientific level remains `level_1`.
- Governing close-contact detection decision: `JM-DEC-024`

The production Single Attempt response now explicitly communicates that
multi-person interaction evidence is insufficient while preserving valid
single-subject capabilities.



## Boundary-Normalized Landmark Reporting Gate

- Gate implementation: `COMPLETE`
- Regression test: `PASS`
- Test count: `1/1`
- Inference rerun required: `NO`
- Governing analysis: Single Attempt V2A, Level 1

### Run 01 Result

- `UM-TIM-001`: `reportable` ? `5.000 s`
- `UM-ANG-001`: `review_required` ? projected trunk inclination `4.79 deg`
- `UM-ANG-002`: `reportable` ? projected right support-leg knee angle `167.21 deg`

The trunk metric is review-required because one of its required landmarks
(`left_shoulder`) required boundary normalization from an out-of-image model
estimate.

The knee metric remains reportable because its required right-side hip, knee
and ankle landmarks were not boundary-normalized.

Multi-person evidence remains `insufficient`, and interaction metrics remain
non-reportable.



## UM-ANG-003 Implementation Record

- Metric ID: `UM-ANG-003`
- Name: Projected attacking-leg knee angle
- Status: `IMPLEMENTED`
- Scientific level: `Level 1`
- Provenance: `model-estimated`
- Method version: `projected-knee-angle-1.0.0`
- Attacking-leg classification source: `human-confirmed`
- Automatic attacking-leg inference: `NOT ALLOWED`
- Boundary-normalization reporting gate: `ACTIVE`
- Regression tests: `2/2 PASS`
- New model inference required for Run 01: `NO`

### Run 01

- Human-confirmed attacking leg: `left`
- `UM-ANG-003`: `157.99 deg`
- Status: `reportable`

If attacking-leg confirmation is absent, `UM-ANG-003` is withheld.



## UM-ANG-004 Method Definition Gate

- Metric: `UM-ANG-004 ? Projected attacking-leg hip angle`
- Implementation status: `BLOCKED ON METHOD DEFINITION`
- Scientific level target: `Level 1`
- Current registry specifies:
  - trunk/pelvis proxy
  - attacking hip
  - attacking knee
  - declared image-plane segment angle
- Missing:
  - exact reference axis
  - exact geometric definition
  - versioned formula
- Implementation is not permitted until these are explicitly defined.
- No software formula was invented.
- No model inference was performed.



## V2A Four-Metric Regression Stability

- Approved V2A metric set:
  - `UM-TIM-001`
  - `UM-ANG-001`
  - `UM-ANG-002`
  - `UM-ANG-003`
- Targeted regression suite: `9/9 PASS`
- Existing API response contract updated to four metrics.
- Boundary-normalization gate preserved.
- Human-confirmed attacking-leg gate preserved.
- Missing attacking-leg confirmation continues to withhold `UM-ANG-003`.
- No model inference was performed during regression validation.
- `UM-ANG-004` remains deferred pending a formally defined versioned method.


## Experimental Neutral Identity Tracker Prototype

- Implementation status: `EVALUATION-ONLY / NOT PRODUCTION-APPROVED`
- Adapter:
  `ai_engine/tracking/experimental_rtmlib_iou_tracker.py`
- Existing protocol: `NeutralIdentityTracker`
- Baseline primitive: RTMLib `0.0.16` greedy previous-frame bounding-box IoU
- Baseline IoU threshold: `0.3`, retained only for engineering comparison and
  not scientifically validated
- Input: existing role-neutral `PoseDetection2D` observations; no model call
  or video inference is performed by the adapter
- Output identities remain `Track A`, `Track B`, `Track C`, and so on; no
  Tori/Uke role is inferred
- Association confidence remains unavailable and is never derived from IoU
- Multi-candidate overlap, multi-person detection collapse, disappearance and
  unverified reappearance fail closed without silent identity restoration
- Detection order is recorded only as a frame-local event and is not used as
  athlete identity
- Synthetic tracker plus existing contract regression tests: `29/29 PASS`
- V2A production analysis, scientific metrics and JM-DEC-024 are unchanged
- Real-video identity accuracy remains unevaluated
