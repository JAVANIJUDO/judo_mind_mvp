﻿# Judo Mind Changelog

All important changes and development milestones are recorded here.

---

# Version 0.12

Status:
Stable Development


## Added

- Flutter project foundation created.
- Git version control enabled.
- Project migrated to D drive for better storage management.
- Multi-language structure started.
- Technique model architecture created.


## Techniques Module

Implemented:

- Technique list screen.
- Technique detail screen.
- Technique card component.
- Search system.
- Category filters.
- Difficulty filters.
- Filter bottom sheet.


## Sample Techniques

Implemented:

- Uchi Mata
- Seoi Nage
- Additional technique samples


---

# Version 0.13

Status:

Architecture Preparation Phase


## Added

### Documentation Foundation

Created:

- AI_DEVELOPMENT_RULES.md
- ARCHITECTURE.md
- CHANGELOG.md
- DECISION_LOG.md
- PROJECT_STATUS.md
- PRODUCT_REQUIREMENTS.md


### Development Foundation

Completed:

- Git workflow preparation
- Documentation workflow
- Initial modular architecture preparation
- Repository pattern preparation
- Local data source preparation
- Technique Bundle model architecture


## Techniques Module

Implemented:

- Technique data model expansion
- Technique repository structure
- Technique local data architecture
- Sample technique database preparation


## Technical Decisions

Approved:

- Feature-based architecture direction
- Provider state management
- Future Riverpod migration readiness
- Documentation synchronization rule


---

# Version 0.14

Status:

In Development


## Title:

Architecture Stabilization + Technique Intelligence Phase


## Added


### Technique UI 2.0

Implemented:

- Technique Dashboard Item
- Technique Dashboard Grid
- Technique Bottom Sheet architecture


### User Experience Improvements

Approved:

- Dashboard-based navigation
- Reduced long scrolling pages
- Section-based technique access


Technique sections:

- Overview
- Technical Analysis
- Biomechanics
- Training
- Shadow Training
- Conditioning
- Competition Analysis
- Combinations
- Counters
- Quiz
- Sources
- Progress
- AI Recommendations


---

## Technique Intelligence System

Architecture added:


### Technical Layer

- Kuzushi
- Tsukuri
- Kake
- Execution Steps
- Common Mistakes


### Biomechanics Layer

- Movement Analysis
- Force Direction
- Center of Gravity
- Muscle Activation


### Training Layer

- Shadow Training
- Uchikomi
- Nagekomi
- Conditioning
- Mobility


### Competition Layer

- Tactical Application
- Combination
- Counter
- Match Analysis


### AI Layer

- Progress Analysis
- Recommendations
- Personalized Training


---

## Internationalization

Approved:

- Localization First Strategy
- ARB localization architecture
- RTL/LTR preparation


Supported languages:

- English
- Persian
- French
- German
- Spanish
- Japanese
- Russian
- Arabic


---

## Product Architecture

Approved:

Judo Mind official 17 module structure.


Module 17:

Administration & System Settings


---

## CMS Architecture

Approved:


Future Administration Panel will manage:

- Techniques
- Images
- Videos
- News
- Courses
- Champions
- Quiz
- Advertisements
- Home Dashboard
- Translations
- Media Library

## Version 0.14.1

Status:
In Development


### Technique Module 2.0 Integration


Added:

- Technique Dashboard Grid enhancement
- Added Biomechanics section
- Added Shadow Training section
- Added Conditioning section
- Added Progress section
- Expanded Technique Dashboard architecture


Improved:

- Reduced long scrolling dependency
- Prepared section-based navigation
- Improved scalability of Technique Detail module


Architecture:

Updated:

- Technique Dashboard navigation
- Section component strategy
- Bottom Sheet integration preparation


Testing:

- flutter analyze passed successfully

## Version 0.14.2

Status:
In Development

### Technique Detail Integration - Phase 1

Added

- Technique Dashboard imports
- Technique Bottom Sheet imports

Verified

- flutter analyze passed

Architecture

- Preparing Dashboard Integration

## Version 0.14.3

Status:
In Development


### Technique Dashboard Connection

Completed:

- Connected Technique Detail Screen with Dashboard Grid.
- Connected Technique Bottom Sheet architecture.
- Fixed Quiz data binding with TechniqueModel.


Validation:

- flutter analyze passed successfully.

## Version 0.14.4

Status:
In Development


### Overview Section Implementation


Added:

- First Technique Dashboard content section.
- Overview Section widget.
- Technique data binding with Overview.


Architecture:

- Section-based content rendering validated.
- Dashboard to Bottom Sheet flow confirmed.


Validation:

- flutter analyze passed successfully.

## Version 0.14.5

Status:
In Development

### Technique Detail Refactor â€” Hero Section

Completed:

- Created reusable HeroSection widget.
- Moved technique title and favorite control into an independent component.
- Connected HeroSection to TechniqueDetailScreen.
- Connected real Overview and Technical Analysis sections to Bottom Sheets.

Validation:

- flutter analyze passed without errors.

## Version 0.14.6

Status:
In Development

### Technique Detail Refactor â€” Media Section

Completed:

- Created reusable MediaSection widget.
- Moved technique image and video presentation out of TechniqueDetailScreen.
- Replaced raw video URLs with professional video cards.
- Added media loading and invalid-link feedback.
- Preserved training and competition video actions.
- Reduced TechniqueDetailScreen responsibilities.

Validation:

- flutter analyze passed without errors.

## Version 0.14.7

Status:
In Development

### Technique Detail Refactor â€” IJF Profile

Completed:

- Created reusable IjfProfileSection.
- Moved IJF classification data out of TechniqueDetailScreen.
- Added a professional official-content badge.
- Improved IJF information hierarchy and visual density.
- Preserved localized labels.

Validation:

- flutter analyze passed without errors.

## Version 0.14.8

Status:
In Development

### Technique Detail Refactor â€” Description Section

Completed:

- Created reusable DescriptionSection.
- Moved technique description out of TechniqueDetailScreen.
- Preserved localized technique descriptions.
- Added empty-content fallback.
- Improved text readability and visual hierarchy.

Validation:

- flutter analyze passed without errors.
---

# Version 0.15

Status:

Planned


## Backend Preparation

Planned:

- CMS Architecture
- REST API Architecture
- Authentication
- Database Architecture
- Media Storage
- Cloud Infrastructure


## Design System

Planned:

- Color System
- Typography
- Icons
- Buttons
- Cards
- Dialogs
- Bottom Sheets
- Theme Management


## Administration Foundation

Planned:

- Admin Panel architecture
- Role management
- Permission system
- Content management foundation

## Version 0.15.0

Status:
Design System Development

### Approved

- Judo Mind Design System 1.0
- Centralized visual language for all 17 modules
- Global card, button, typography, spacing and radius standards
- RTL and LTR compatibility requirement
- Dark-theme-first architecture
- Reusable component strategy
---
## Version 0.16.0

Status:
Reference Technique Completion Phase

### Approved

- Uchi Mata selected as the official Reference Technique.
- Five-layer learning flow approved:
  Watch, Understand, Practice, Analyze and Master.
- Universal video-upload access approved.
- AI credit-based usage model approved.
- Sensi Bot AI Fight Intelligence 360 approved.
- Opponent guard, position and balance analysis approved.
- Push and pull reaction analysis approved.
- Technique Dashboard established as the primary navigation system.

### In Progress

- Removal of duplicated Technique Detail content.
- Connection of all Dashboard sections.
- Compact Dashboard polish.
- Uchi Mata visual-learning architecture.
- AI Analysis entry-point design. 

# Version 0.16

Status:

Planned


## Athlete Ecosystem Expansion

Planned:

- Athlete Profile
- Monitoring System
- Progress Tracking
- Training History
- Performance Analytics


---

# Version 0.17

Status:

Planned


## AI Development

Planned:

- Sensi Bot Foundation
- AI Knowledge Layer
- Recommendation Engine
- Personalized Training Support


---

# Version 1.0

Status:

Target Release


## Version 0.17.0 â€” JMDS Dashboard Icon Foundation

Date: 2026-08-02  
Status: Completed

### Added

- Added the centralized `JudoIcons` registry.
- Added the standard `JudoIcon` Design System widget.
- Migrated Technique Dashboard icons to the Judo Mind icon registry.
- Rebuilt `TechniqueDashboardItem` using JMDS components.
- Added standardized icon highlighting and semantic labels.
- Added compact AI and quiz badges.
- Added consistent disabled and locked states.

### Changed

- Reduced Technique Dashboard icon size to 19 px.
- Removed unnecessary decorative circles from dashboard cards.
- Reduced visual density and unused card space.
- Standardized card border, radius, spacing and typography.
- Prepared dashboard icons for future SVG and illustration replacement.

### Validation

- Dart formatting completed.
- Flutter Analyze passed without errors.
- Existing Dashboard navigation and Router behavior preserved.

## Professional Judo Mind MVP


Includes:

- 17 Modules
- Complete Technique Platform
- Sensi Bot Foundation
- Training Center
- Monitoring
- Athlete Profile
- Coach Panel
- Club Panel
- Competition Module
- News Center
- Online Courses
- Subscription System
- CMS
- Administration Panel
- Multi-language System
- Design System
- Backend Ready Architecture

### Design System 1.0 â€” Typography

Added:

- Centralized JudoTypography system
- Display, heading, title, body and label hierarchy
- Brand-specific technique title styles
- Responsive technique-title helper
- Preparation for language-specific font management

## Version - JM-DS-005

### Added
- Added JudoCard core UI component
- Added JudoSection reusable layout component
- Integrated Design System components
- Prepared shared UI architecture for all modules

### Impact
- Technique Detail module can migrate to reusable components
- Future modules will use centralized UI components

### JM-UX-012 â€” Media Architecture

- Replaced duplicated MediaSection on Technique Detail with TechniqueMediaPreview.
- Full media library is now accessible through the Videos dashboard section.
- Added branded official-media preview.
- Added support for asset and network preview images.
- Added media-count calculation.
- Prepared the reference technique for professional media metadata.

### JM-MEDIA-002 â€” Professional Technique Media Model

Added:

- TechniqueMediaItem model
- Professional media titles and descriptions
- Media type classification
- Verified-source classification
- Duration and thumbnail metadata
- Competition and athlete metadata
- Grip and attack-direction metadata
- Top-execution ordering
- AI-compatible media tags

The previous raw URL media structure will be migrated gradually without breaking the current application.

### JMDS-006 â€” Custom Illustration Renderer

- Added reusable JudoIllustration component.
- Added CustomPainter-based illustrations.
- Added initial support for Sensi Bot, Quiz, Training, Competition and Mastery.
- Added technical, tactical, grip, balance, champion and safety visual variants.
- Added semantic accessibility labels.
- Added dark-theme-compatible vector rendering.
- No external illustration dependency was introduced.

### JMDS-006 â€” Custom Illustration Renderer

- Added reusable `JudoIllustration` component.
- Added CustomPainter-based vector illustrations.
- Added initial support for Sensi Bot, Quiz, Training, Competition and Mastery.
- Added technical, tactical, grip, balance, champion, combination and safety variants.
- Added semantic accessibility labels.
- Added dark-theme-compatible vector rendering.
- Introduced no external illustration dependency.
- Flutter Analyze completed without errors.

### JMDS-007 â€” Selective Dashboard Illustration Integration

Date: 2026-08-02
Status: Completed

- Added optional illustration support to `TechniqueDashboardItem`.
- Connected custom JMDS illustrations to Training, Competition, Mastery, Sensi Bot and Quiz.
- Kept standard dashboard sections icon-based to control visual density.
- Preserved all Dashboard navigation and Router behavior.
- Added semantic labels for custom visuals.
- Updated card proportions for illustration-based content.
- Dart formatting completed.
- Flutter Analyze passed without errors.

### JM-MEDIA-005 â€” Professional Media Library

Date: 2026-08-02
Status: Completed

- Rebuilt MediaSection using TechniqueMediaResolver.
- Removed raw URL display from media cards.
- Added professional media titles and source labels.
- Added Featured Media presentation.
- Added categorized media collections.
- Added verified, premium and media-type indicators.
- Added direct-media URL validation.
- Blocked YouTube search-result URLs.
- Added image preview dialog.
- Added support for official, training, competition, Top Execution and analysis media.

---

# Version 0.14.2

Status:

In Development

## Title

Three-Layer Visual Learning Architecture

## Added

### Visual Learning Foundation

- Three-layer visual learning model
- Technique visual learning plan
- Reusable visual learning sequence architecture
- Layer visibility controls
- Animation playback controls
- Playback speed controls

### Visual Layer System

Implemented:

- Blue movement layer
- Gold control layer
- Green biomechanics layer
- Individual layer activation
- Synchronized layer playback

### Uchi Mata Reference Technique

Implemented:

- Uchi Mata visual learning data
- Uchi Mata biomechanics sequence
- Uchi Mata shadow-training sequence
- Uchi Mata conditioning sequence
- Tori and Uke visual separation
- Kuzushi phase indicator
- Tsukuri phase indicator
- Kake phase indicator
- Animated footwork path
- Animated grip-control visualization
- Center-of-gravity visualization
- Force-direction visualization

### Dashboard Integration

Added:

- Biomechanics Dashboard section
- Shadow Training Dashboard section
- Strength & Conditioning Dashboard section

### Design System

Updated:

- Judo Mind icon registry expanded
- Visual-learning icons centralized
- Three-layer colors connected to Design Tokens

## Validation

Completed:

- Flutter compilation validation
- Physical-device visual validation
- Three-layer animation playback validation
- Layer toggle validation
- Playback-speed validation

## Current Limitation

The current Tori and Uke figures are functional vector prototypes.

Future refinement will replace them with professional Judo Mind illustrations or advanced animation assets while preserving the approved three-layer architecture.

# Version 0.14.3

Status:

In Development

## AI Fight Intelligence 360 â€” Video Input Foundation

Implemented:

- Technique video selection from device gallery
- Direct video recording entry
- Local video preview
- Video playback
- Video file metadata
- Camera-angle selection
- Scientific analysis disclaimer
- Analysis consent workflow
- Prepare AI Analysis action
- Uchi Mata AI Analysis routing

## Biomechanical Analysis Architecture

Added structured support for:

- Tori pose tracking
- Uke pose tracking
- Joint-angle measurements
- Kuzushi detection
- Tsukuri detection
- Kake detection
- Center-of-mass tracking
- Biomechanical findings
- Confidence scoring
- Camera calibration metadata
- Video overlay output
- Analysis limitations

## Validation

Physical Android device validation completed successfully.

Video selection, preview, camera-angle selection and analysis preparation workflow verified.

---

# Version 0.15

Status:

In Development

## Title

AI Fight Intelligence 360 + Scientific Biomechanics Foundation

Date:

2026-08-05

---

## Uchi Mata Visual Learning

Added:

- Three-Layer Visual Learning architecture
- Movement Layer
- Control Layer
- Biomechanics Layer
- Layer visibility controls
- Animation playback controls
- Playback speed controls
- Uchi Mata technical-execution visual sequence
- Uchi Mata biomechanics visual sequence
- Shadow Training visual sequence
- Strength & Conditioning visual sequence

Approved visual language:

- Blue = Movement / Footwork
- Gold = Grip / Pull / Upper-Body Control
- Green = Force / Balance / Center of Gravity

Current CustomPainter implementation is classified as an instructional prototype rather than final biomechanical visualization.

---

## AI Fight Intelligence 360 â€” Flutter Foundation

Added:

- Analyze My Uchi Mata entry
- AI Analysis Dashboard routing
- Video selection from device
- Video recording entry
- Selected-video preview
- Video metadata display
- Camera-angle selection
- Scientific analysis disclaimer
- AI analysis preparation flow

Architecture:

Flutter is responsible for:

- Capture
- Upload
- Configuration
- User interaction
- Analysis result visualization

Heavy AI processing is delegated to the AI backend.

---

## Professional AI Analysis Models

Added:

- Expanded MediaAnalysisMetadata
- Structured biomechanical findings
- Confidence metadata
- Analysis status
- Technique phase metadata
- Joint-angle measurement architecture
- Center-of-mass data preparation
- Analysis limitations
- Overlay and report references
- VideoAnalysisRequest architecture
- BiomechanicsAnalysisService contract

---

## Python AI Engine

Created:

`ai_engine/`

Added:

- Python 3.12 AI environment
- FastAPI backend
- Uvicorn service
- Health endpoint
- Video upload endpoint foundation
- OpenCV processing
- MediaPipe integration
- MediaPipe Pose Landmarker Heavy
- RTMLib integration
- ONNX Runtime
- RTMPose integration
- PoseTracker evaluation
- RTMO evaluation

---

## Real Judo Video Benchmark

A single real Judo competition video was used as the common benchmark.

Video:

- Duration: 53.89 seconds
- Resolution: 1306 Ã— 720
- Source FPS: approximately 30
- Analyzed frames: 540
- Target analysis rate: approximately 10 FPS

Results:

| Engine | At Least One Athlete | Two Athletes |
|---|---:|---:|
| MediaPipe Heavy | 99.63% | 31.48% |
| RTMPose-M | 97.04% | 48.33% |
| RTMPose-M + PoseTracker | 96.85% | 46.85% |
| RTMO-M | 40.56% | 8.15% |

Decision:

RTMPose-M is the current baseline pose-estimation engine.

RTMPose-M is not considered sufficient by itself for production-grade Judo biomechanics.

---

## Scientific Biomechanics Architecture

Approved:

JM-DEC-017 â€” Scientific Biomechanics & Multi-View Motion Analysis Architecture

Major architectural decision:

Pose estimation is no longer considered the complete biomechanics system.

Approved pipeline:

Video Capture

â†“

Camera Calibration and Synchronization

â†“

Multi-Person Pose Estimation

â†“

Tori / Uke Identity

â†“

Occlusion Intelligence

â†“

Multi-View 3D Reconstruction

â†“

OpenSim Musculoskeletal Modeling

â†“

Judo-Specific Biomechanics

â†“

AI Fight Intelligence

â†“

Scientific Quality Validation

---

## OpenSim Integration Foundation

Added:

Dedicated scientific biomechanics environment:

`ai_engine/.biomech_venv`

Installed:

- Python 3.12
- OpenSim 4.6
- NumPy 2.5.1

Validation:

OpenSim successfully initialized.

Verified:

`Judo Mind OpenSim Engine: READY`

OpenSim is approved as the primary musculoskeletal modeling and biomechanical computation engine.

---

## Scientific Analysis Levels

Added:

### Standard Analysis

Single-video analysis with estimated technical, tactical and biomechanical indicators.

### Advanced Biomechanics

Two or more synchronized and calibrated cameras for multi-view 3D reconstruction and model-based biomechanics.

### Research / Validation

Support direction for:

- Marker-based Motion Capture
- Force Plates
- EMG
- IMU
- Laboratory reference systems

---

## Scientific Integrity Rule

Added:

Judo Mind must explicitly distinguish:

- Measured data
- Reconstructed data
- Model-estimated data
- AI-inferred data

Estimated physical quantities must never be presented as directly measured quantities.

Every professional biomechanical result must eventually include:

- Confidence
- Data source
- Analysis method
- Quality classification
- Relevant limitations

---

## Infrastructure Architecture

Current local processing:

CPU-based development and benchmarking.

Production direction:

GPU-backed AI processing.

Computer Vision environment:

`ai_engine/.venv`

Scientific Biomechanics environment:

`ai_engine/.biomech_venv`

The two environments remain isolated to prevent dependency conflicts.

---

## Current Development Direction

Reference Technique:

Uchi Mata

Next scientific implementation target:

Multi-View 3D Motion Reconstruction

Required foundation:

- Camera calibration
- Camera synchronization
- Tori / Uke identity
- Multi-camera landmark matching
- 3D triangulation
- OpenSim-compatible motion data

---

## Repository Development Governance

Date:

2026-08-06

Status:

Completed

### Added

- Added the root `AGENTS.md` repository instruction file.
- Required the five approved project reference documents to be read before future project work.
- Consolidated preservation of existing user work and existing functionality.
- Consolidated mandatory documentation synchronization for feature, architecture, product, and development-process changes.
- Consolidated the scientific distinction between measured, reconstructed, estimated or model-estimated, and AI-inferred data.
- Required explicit user approval before destructive Git operations or Git push.
- Recorded the current Uchi Mata reference stage and Flutter plus Python AI Engine responsibility boundary.
- Preserved the official 17-module product structure.

### Documentation

- Updated `AI_DEVELOPMENT_RULES.md` for the repository-level agent instruction entry point.
- Updated `PROJECT_STATUS.md` to record the completed governance file.
- No new product or architecture decision was introduced.

---

## Stereo Calibration Cycle Closure and Scientific Pipeline Guard

Date:

2026-08-07

Status:

Completed

### Calibration conclusion

- Closed the current approximately 48-hour two-phone stereo test cycle; no further tests are authorized on the two source videos.
- Recorded that the +0.55 s geometric correction did not solve the geometry and worsened stereo RMS from the previously recorded 39.26 px to 48.2750333 px.
- Recorded median epipolar error of 55.4328918 px and final quality `review_required`.
- Preserved the valid intrinsic findings for cameras 101 and 102 and the confirmed camera orientations.
- Scientifically rejected the current stereo extrinsic for 3D reconstruction, biomechanics and OpenSim.
- Recorded stabilization/EIS/OIS virtual-camera change only as an unconfirmed hypothesis.

### Architecture

- Approved JM-DEC-018, separating Single-Camera AI Analysis from Multi-Camera 3D Scientific Analysis.
- Required confidence, limitations and explicit provenance for all analysis outputs.
- Prohibited single-camera or uncertain outputs from being described as measured or reconstructed 3D.
- Defined calibration, synchronization, cross-camera identity, geometry and reconstruction-quality gates before advanced scientific use.

### Safeguard

- Added a centralized fail-closed stereo calibration quality gate.
- Required a sealed validated-calibration context before `MultiViewReconstructor` can run.
- Limited `usable_for_3d_validation` calibration to offline validation.
- Required `good` or `excellent` calibration plus the existing numeric acceptance thresholds for user-facing scientific 3D.
- Kept OpenSim behind additional identity, motion, reconstruction and anatomical-quality gates.
- Added synthetic, video-free regression tests for invalid, missing, validation-only and scientific calibration cases.

### Validation

- Six calibration-gate and reconstruction-guard unit tests passed without processing calibration videos.
- No Flutter source was changed; `flutter analyze` was therefore not required for this change.

---

## Single-Camera Uchi Mata AI Analysis v1 â€” Vertical Slice 1

Date:

2026-08-07

Status:

Implemented, automated-test validated and physical-device end-to-end validated

### Added

- Added the versioned `POST /v1/analysis/single-camera/pose-summary` Python endpoint.
- Added a bounded API response for measured video metadata and model-estimated pose coverage.
- Added explicit capability flags and scientific limitations for unavailable identity, phases, 3D reconstruction, force and torque.
- Added Flutter API configuration through `JUDO_MIND_AI_BASE_URL` and an HTTP multipart implementation.
- Connected the existing Analyze video selection flow to the Python AI Engine.
- Added loading, failure and real diagnostic-result states to the Analyze screen.
- Added a localized Single-Camera Pose Summary card with provenance labels and limitations.
- Added debug-only Android cleartext HTTP support for local AI Engine development.
- Replaced the ambiguous `3D` badge on the educational Biomechanics dashboard card with `Learn`.

### Scientific safeguards

- Pose coverage is labeled `model-estimated` and is not presented as biomechanical confidence.
- Video metadata is labeled `measured`; no landmark is presented as measured or reconstructed 3D.
- Flutter fails closed if the single-camera response claims persistent athlete identity, phase detection, 3D reconstruction, force or torque.
- The current MediaPipe Pose Landmarker Heavy engine is identified as an experimental baseline, not a production Judo biomechanics engine.
- No Tori/Uke identity, Kuzushi/Tsukuri/Kake phase, joint-angle, center-of-mass, force, torque, 3D or OpenSim result is produced by this slice.

### Validation

- Added two synthetic, video-free Python tests for the versioned contract, scientific boundary, temporary-upload cleanup and non-video rejection.
- Added three Flutter tests for JSON/provenance parsing, multipart request wiring and scientific result rendering.
- All new Python and Flutter tests pass.
- `flutter analyze` was run; no diagnostic is attributable to the new vertical-slice code, while 20 existing repository warnings/information diagnostics remain outside this change.
- Completed a real physical-Android end-to-end validation with a new 23.72-second, 640x1136, 25 FPS single-camera Uchi Mata competition clip.
- Confirmed the complete Flutter multipart upload -> FastAPI -> MediaPipe Pose Landmarker Heavy -> versioned `1.0.0` JSON -> Flutter parsing -> Result Card path with final HTTP 200.
- Recorded 297 analyzed frames, 97% model-estimated coverage for at least one pose and 7% for two poses; these values remain diagnostic coverage rather than identity or biomechanics confidence.
- Recorded that the then-current integer-stride sampler analyzed approximately 12.5 FPS for this 25 FPS source despite the requested 10 FPS target; this historical result is preserved, and a later uncommitted timestamp-sampler correction still requires real-video validation.
- Confirmed all five scientific limitations were visible and no affirmative Tori/Uke identity, phase, 3D, force or torque claim was rendered.
- Confirmed the backend temporary upload was removed after processing; local CPU processing took approximately 4 minutes 40 seconds and remains unsuitable for production latency.
- No test was run on the closed Stereo video pair and no calibration or multiview file was changed.
- Manual end-to-end validation with a new single-camera Uchi Mata clip passed on 2026-08-07.

---

## Uchi Mata Scientific Metrics v1 and Fight Intelligence 360 Levels

Date:

2026-08-08

Status:

Scientific/product architecture documented; no analysis implementation added

### Added

- Added `docs/UCHI_MATA_SCIENTIFIC_METRICS_V1.md` as the versioned scientific metric contract.
- Formalized three independent Fight Intelligence 360 levels: Single-Camera AI, Multi-Camera 3D and Professional/Federation/Laboratory.
- Defined metric IDs, required inputs, methods, units, level, provenance, confidence evidence, scientific sources and allowed/prohibited interpretations.
- Defined Level 1 projected timing, angle, displacement, velocity, grip, foot-placement, relative-position, 2D COM-proxy and Uke balance-displacement candidates.
- Defined Level 2 reconstructed 3D skeleton, trajectories, joint geometry, relative positioning, velocity, model-estimated COM and reference-comparison candidates.
- Defined Level 3 measured force/sensor inputs and model-estimated momentum, inverse-dynamics, moment, work and power candidates.
- Recorded the five approved Uchi Mata DOI sources and their methodological limits.
- Recorded source-specific phase/event definitions and prohibited silent mapping to canonical Kuzushi/Tsukuri/Kake labels.
- Defined Interactive 3D/360 as virtual-camera viewing of a validated reconstructed scene.
- Defined AI Sensi, annotated-video, voice-coaching and scientific-report coordination and preserved Blue/Gold/Green overlay semantics.

### Scientific safeguards

- Preserved the JM-DEC-018 fail-closed calibration and OpenSim gates.
- Preserved the rejected `review_required` stereo disposition and the ban on retesting its source videos.
- Prohibited invented normative thresholds and promotion of provenance.
- Required Level 1 Green arrows to be AI-inferred conceptual cues rather than measured force vectors.
- Classified champion-specific and small-sample study findings as reference evidence, not universal ideals.

### Validation

- Documentation-only consistency review completed against AGENTS.md and all mandatory reference documents.
- No Flutter or Python source was changed, so no application test or `flutter analyze` run was required.
- No Stereo/Multiview test was run.

---

## Night Shift 01 â€” Pose Reliability Foundation

Date:

2026-08-08

Status:

Implementation and synthetic validation complete; real-video execution blocked

### Added

- Added a shared deterministic nearest-target-timestamp video sampling plan.
- Added unit coverage for 25 FPS to 10 FPS sampling, the prior 593-frame source
  shape, source-rate capping and invalid sampling inputs.
- Added a non-production pose benchmark harness with the same video/timestamps
  for MediaPipe Heavy, RTMPose-M and RTMO-M.
- Added versioned JSON and human-readable benchmark reporting for pose coverage,
  runtime, effective analyzed FPS, confidence availability and failures.
- Added role-neutral tracking contracts for `Track A`, `Track B` and later
  tracks, plus synthetic continuity evaluation for crossing, occlusion and
  reappearance.
- Added `docs/AI_POSE_ENGINE_AUDIT.md` with the actual current engine/model,
  dependency, keypoint, confidence, CPU, tracking and limitation matrix.

### Corrected

- Replaced the integer-stride behavior that converted a requested 10 FPS on a
  25 FPS source into approximately 12.5 analyzed FPS.
- Recorded that `ai_engine/rtmpose_engine.py` actually initializes RTMO-M, while
  the diagnostic default `Body(...)` path initializes YOLOX-M + RTMPose-M.
- Kept historical real-video results intact and classified the new 238-frame
  value as a sampling-plan calculation rather than a new video result.

### Scientific safeguards

- Pose detections remain `model-estimated`; neutral track association remains
  `AI-inferred`.
- The tracking contract rejects Tori/Uke role labels and makes no real-video
  continuity claim.
- The benchmark produces no phase, measured/reconstructed 3D, force, torque,
  OpenSim or coaching result.
- No old Stereo/Calibration video was processed or modified.

### Validation

- 20 focused Python unit tests pass.
- Added a backend regression test proving temporary upload cleanup when pose
  inference fails with a bounded HTTP 500 response.
- Python syntax compilation and `git diff --check` pass.
- `BLOCKED â€” TEST VIDEO REQUIRED`: no explicit single-camera Uchi Mata video is
  currently available; only excluded closed Stereo/Calibration videos exist.
- No Flutter source changed, so `flutter analyze` was not required.

### Safe fallback audits

- Added `docs/NIGHT_SHIFT_01_AUDIT.md` covering single-camera test gaps, all 20
  pre-existing Dart diagnostics, the 17 official modules and AI technical debt.
- Classified 4 diagnostics as real unused-code maintenance debt, 10 as
  stylistic/cleanup, 0 as generated and 6 as potentially risky compatibility or
  feature-gating debt; no bulk fix was made.
- Recorded that no official Module 18 exists and that the source dashboard has
  unresolved official-module/non-official-tile mismatches.
- Added an offline cache preflight so the benchmark cannot silently download
  missing RTMLib models.

---

## Autonomous Development Shift 01 â€” Reliability Hardening and Module 18

Date:

2026-08-08

Status:

Implementation and offline validation complete; real-video and Flutter-tool
validation blocked

### Added

- Added deterministic sampler coverage for 24/25/30/50/60 FPS, non-integer
  source rates, short clips, end boundaries and integer-millisecond tie cases.
- Added benchmark coverage for no-, one- and two-pose sequences, missing
  dependencies, isolated runner failure, timing derivation and stable JSON
  serialization.
- Added neutral tracking evaluation for detection-order swaps, one-person
  intervals and explicit track termination/reinitialization.
- Added Flutter contract tests for incompatible schema/status, provenance
  promotion, false confidence availability, missing limitations and stale/wrong
  endpoint diagnostics.
- Formalized `AI Training Plan Intelligence` as approved Module 18 in
  architecture, product requirements, project status and JM-DEC-020.

### Corrected

- Replaced bankers rounding for sampling timestamps with deterministic half-up
  millisecond mapping and a strict no-duplicate timestamp invariant.
- Preserved source-relative result timestamps while keeping MediaPipe VIDEO
  timestamps monotonic when a shared landmarker processes more than one video.
- Made failed benchmark runners return the same metric-key schema as successful
  runners without inventing coverage, confidence or timing values.
- Closed upload-stream cleanup gaps for invalid media and empty technique IDs.
- Strengthened Flutter fail-closed parsing to require the `1.0.0` completed
  single-camera contract, measured video metadata, model-estimated pose
  coverage, unavailable confidence, prohibited capabilities and all required
  interpretation limitations.

### Scientific safeguards

- Pose coverage remains `model-estimated`; it is not a confidence score.
- Neutral track association remains `AI-inferred` and never assigns Tori/Uke.
- Module 18 recommendations are specified as evidence-aware `AI-inferred`
  decision support, not medical diagnosis or a universally correct plan.
- No phase, 3D, force, torque, joint moment/power, COM coaching, OpenSim or
  automatic AI Sensi technique claim was introduced.
- No Stereo/Multiview/Calibration video was processed or changed.

### Validation

- 37 focused Python tests pass.
- Dart formatting validation reports zero remaining format changes for the
  changed Dart files.
- Targeted Flutter test and Dart analyzer commands timed out without output in
  the current environment; no running process or system setting was altered.
- `BLOCKED â€” TEST VIDEO REQUIRED`: no explicitly authorized single-camera Uchi
  Mata video is present, so no real benchmark was run and the historical real
  two-person coverage remains approximately 7%.
- All changes remain unstaged and uncommitted; no push was performed.

---

## Single-Camera Pose Benchmark Performance Controls

Date:

2026-08-08

Status:

Diagnosis and lightweight validation complete; FAST SCREENING not run

### Diagnosed

- Confirmed the authorized 110.72-second, 640 x 360, 25 FPS source has 2,768
  native frames and a deterministic 1,108-sample 10 FPS plan.
- Recovered complete MediaPipe Heavy timing of 1,041.077 seconds for
  1,108/1,108 samples and complete RTMPose-M timing of 8,658.745 seconds for
  1,108/1,108 samples.
- Identified RTMPose-M's synchronous YOLOX-M plus RTMPose-M CPU model call as
  the supported dominant bottleneck; initialization was only 2.727 seconds.
- Confirmed both completed engines inferred only the shared sampled frames,
  although OpenCV sequentially decoded the full source stream.
- Confirmed no retry loop, completed RTMPose did not hang, and no CUDA/GPU was
  used. RTMO was cancelled without a recoverable frame count or final artifact.

### Added

- Added per-engine progress with processed/total samples, elapsed time,
  effective FPS and reliability-gated ETA.
- Added cooperative per-engine timeout and graceful cancellation, partial
  observations for interrupted engines, independent failure continuation and
  atomic checkpoint persistence after every engine.
- Added explicit CPU/device/execution-provider fields and stage timing for new
  runs.
- Added FAST SCREENING with a deterministic content-neutral full-span subset of
  at most 100 timestamps shared exactly by all engines.
- Kept screening outputs limited to pose coverage, available confidence,
  failures and runtime, with manual review required before a longer benchmark.
- Required explicit post-review `--engine` selection for longer CLI benchmarks
  instead of accidentally rerunning every available engine.

### Scientific safeguards

- FAST SCREENING produces no Tori/Uke identity, phase, technique,
  measured/reconstructed 3D, force, torque, COM or biomechanics claim.
- Coverage remains model-estimated and is not confidence.
- The 10 FPS benchmark setting remains an engineering/evaluation choice and is
  not the fixed temporal resolution of future scientific biomechanics.
- No Stereo, Calibration or Multiview data was opened or changed.

### Validation

- 50 focused lightweight Python tests pass; benchmark execution paths use fake
  captures/runners and do not open the authorized real video.
- Python syntax compilation passes for the benchmark controls, engines and
  focused tests.
- The authorized real video was not processed during diagnosis or validation.
- FAST SCREENING remains unexecuted pending Mohammad approval.
- No model/dependency download or install, staging, commit or push was performed.

---

## Real Uchi Mata FAST SCREENING Run 01

Date:

2026-08-08

Status:

Completed with optimized artifact reuse

### Executed

- Built the deterministic, content-neutral 100-timestamp subset by even
  full-span selection from the existing 1,108-sample 10 FPS plan.
- Verified that the complete MediaPipe Heavy and RTMPose-M artifacts retain
  exact frame index, timestamp and pose-count observations for every selected
  sample; neither engine was rerun.
- Ran only RTMO-M on the same 100 timestamps with a 20-minute CPU budget.
- RTMO completed 100/100 samples without failure or timeout in 677.966 seconds
  processing and 681.351 seconds including initialization.
- Created ignored RTMO and combined machine-readable JSON/report artifacts in
  `ai_engine/runtime/benchmark_outputs/`.

### Results

| Engine | Source | >=1 person | >=2 persons | Missing |
|---|---|---:|---:|---:|
| MediaPipe Heavy | Reused artifact | 91% | 25% | 0 |
| RTMPose-M | Reused artifact | 95% | 46% | 0 |
| RTMO-M | New inference | 86% | 42% | 0 |

### Scientific safeguards

- Classified coverage as model-estimated detection coverage, not confidence or
  pose accuracy.
- Did not compare raw confidence magnitudes across model families. Reused
  artifacts do not retain subset-specific confidence aggregates.
- Reported keypoint completeness as unavailable because no common comparable
  per-keypoint artifact contract exists.
- Produced no Tori/Uke identity, phase, technique-quality, COM, biomechanics,
  reconstructed 3D, force, torque, power or OpenSim claim.
- No ground-truth annotation was used, so no pose-accuracy conclusion was made.
- No Stereo, Calibration or Multiview file was opened or modified.

### Validation

- Verified all three engine observation sequences exactly equal the same 100
  frame indices and timestamps.
- Parsed and structurally validated the combined JSON artifact, including
  unique timestamps, result sources, processed/missing counts and limitations.
- No model or dependency was downloaded or installed.
- No Git staging, commit or push was performed.

---

## Fight Intelligence 360 Video Analysis Modes

Date:

2026-08-08

Status:

Architecture and product requirement approved; no feature implementation

### Added

- Added JM-DEC-021, defining three independent analysis scopes: Single Attempt
  Technique Analysis, Drill / Repeated Attempts Analysis and Full Match
  Analysis.
- Defined one primary attempt as the mandatory analysis object for Technique
  Analysis, with useful context before and after and no arbitrary universal
  duration threshold.
- Required reliable segmentation and per-attempt results before repeated drill
  executions may be compared or aggregated.
- Defined Full Match Analysis as an event-detection, attack-segmentation,
  per-attempt and separate match-level tactical pipeline.
- Defined plain-language Analyze UX labels for One Attempt, Multiple Repetitions
  and Full Match.
- Preserved AI Sensi, Annotated Video, Voice Coaching, Scientific Report and
  conditional Interactive 3D/360 as the coordinated result architecture.

### Scientific safeguards

- Kept video-analysis mode independent from Level 1/2/3 scientific capability;
  selecting a mode does not promote provenance or bypass a gate.
- Prohibited blending unsegmented repetitions or match attacks into one
  technique/biomechanics result.
- Prohibited unsupported fatigue inference from repetition change.
- Recorded Pose Engine Benchmark as detection/reliability/performance
  evaluation rather than Technique Analysis.
- Restricted the current timestamp-based 10 FPS setting to benchmark
  infrastructure and required validated metric-specific temporal resolution for
  future scientific extraction.
- Preserved the measured, reconstructed, model-estimated and AI-inferred
  boundary and all identity, phase, 3D, kinetics and OpenSim gates.

### Documentation governance

- Updated `AGENTS.md` and the active AI development rule from the superseded
  current 17-module description to the approved current 18-module architecture.
- Preserved historical 17-module records that were correct before JM-DEC-020.
- Updated architecture, product requirements, project status and development
  rules without changing Flutter or Python implementation code.

### Validation

- Documentation terminology and current/historical module-count consistency
  reviewed.
- No benchmark, video inference, Stereo, Calibration or Multiview processing
  was performed.
- No staging, commit or push was performed.

---

## Single-Attempt Uchi Mata V2A Foundation

Date:

2026-08-08

Status:

Implementation foundation complete; real reviewed attempt pending

### Added

- Added JM-DEC-022 and schema `2.0.0` / `single_attempt_v2a` for the first three
  Level 1 Single-Attempt Uchi Mata metrics.
- Added human-gated contracts for attempt boundaries, Tori selection from a
  neutral track, support leg, angle frame/event and camera suitability.
- Implemented reviewed duration, projected trunk inclination and projected
  support-leg knee-angle math with explicit method versions. Normalized pose
  landmarks are converted to source-image pixel coordinates before angle math
  so non-square frame aspect ratio does not distort the result; overlays remain
  normalized for rendering.
- Added reportable/review-required/withheld states, source frame/timestamp,
  unit, provenance, model landmark visibility semantics, limitations and blue
  overlay primitives.
- Added an internal pure V2A metric evaluator, a public reviewed-video multipart
  endpoint and a frame-local MediaPipe pose adapter that does not infer athlete
  roles. Client-supplied pose landmarks are deliberately absent from OpenAPI.
- Added an exact human-selected source-frame plan, source timestamp validation
  for attempt/angle references and early decode stop after the selected frame;
  the benchmark 10 FPS plan is not used.
- Added versioned human annotation and conditional detection evaluation
  contracts.
- Upgraded ground-truth tooling to schema `1.1.0` with screening-artifact and
  source-video SHA-256 provenance, exact timebase/subset gates, overwrite
  protection and a read-only multi-issue readiness command that never defaults
  human labels.
- Bound every review-image path to its exact sample position, source frame and
  source timestamp, preserved those references through finalization and made
  preparation fail if the screening artifact changes during extraction.
- Added dependency-free CSV export/import for human frame labels, with immutable
  evidence columns, explicit blank-versus-empty semantics, validated new-file
  output and overwrite protection.
- Made frame/timestamp/sample/video-dimension/person-count integer evidence
  strict so boolean and floating-point coercions fail validation.
- Prevented Tori/Uke role-token leakage inside longer role-neutral subject IDs.
- Upgraded path-based readiness to schema `1.1.0`; completion now also requires
  every review JPEG to exist, decode and match source-video dimensions. The
  current ignored set passes at 100/100 readable 640x360 assets.
- Required the conditional artifact evaluator to run the same asset preflight,
  closing the direct in-memory finalization bypass.
- Added self-consistency invariants to serialized readiness reports for label
  counts, status/finalization state and review-asset partitions.
- Centralized create-new output safety for annotation manifests, CSV/merged
  drafts, readiness reports and evaluation JSON so existing work is preserved.
- Upgraded conditional detection evaluation to schema `1.2.0`, verifying the
  artifact/video/subset before reporting overall and broad occlusion/crossing
  slices plus four mutually exclusive occlusion-only/crossing-only/both/neither
  strata whose additive counts must partition the all-frame metrics. Coverage
  remains distinct from confidence, pose accuracy and identity accuracy.
- Extended neutral Track A/B observations with timestamps, uncertainty,
  withheld identity association and crossing/occlusion/reappearance events.
- Hardened neutral Track A/B evaluation with source-timestamp consistency,
  finite geometry/score/confidence checks, controlled event tags and explicit
  same-track/same-detection collision reporting.
- Fixed neutral tracking evaluation provenance: reference labels are
  `human-reviewed` and predicted Track A/B associations are `AI-inferred`.
- Added a typed Flutter reviewed-request/HTTP service, strict V2A parser, result
  card and blue projected-geometry painter with localized English/Persian
  labels.
- Bound every accepted Flutter V2A response back to the initiating reviewed
  request, preventing a valid but stale/crossed video, attempt, track,
  detection, support-leg, frame or camera-review result from being rendered.
- Tightened BLUE geometry in Python and Flutter to normalized in-frame points,
  non-blank labels and the exact approved trunk-line or support-leg-polyline
  plus angle-label structure. Extra, reordered or malformed geometry now fails
  closed.
- Added the first-real-run instructions in
  `SINGLE_ATTEMPT_UCHI_MATA_V2A_RUNBOOK.md`.
- Added exact human labelling definitions, completion gates and artifact
  evaluation commands in `UCHI_MATA_HUMAN_ANNOTATION_GUIDE_V1.md`.

### Review Assets

- Reused the exact deterministic 100-timestamp fast-screening subset and
  extracted 100 review frames plus four contact sheets without pose inference.
- Stored the unfilled annotation template under ignored runtime storage with
  status `awaiting_human_annotation`.
- Confirmed through the new readiness tool that 0/100 frames are complete,
  every required human label remains null, and no label was inferred or
  defaulted.
- Confirmed the authorized source file SHA-256 remained unchanged.

### Scientific Safeguards

- Duration retains the measured video timebase and separately records the
  human boundary source.
- Projected angles remain `model-estimated`; model visibility is not described
  as pose accuracy or biomechanics confidence.
- Withheld spatial metrics expose no value or overlay.
- Automatic Tori/Uke identity, automatic phase labels, normative coaching, 3D,
  force, torque, moment, power, load and injury-risk claims remain unavailable.
- The benchmark 10 FPS target was not adopted as scientific metric resolution.

### Validation

- All 118 Python tests passed, including V2A, annotation/evaluation/tracking
  hardening, benchmark-control and existing V1
  endpoint regression coverage.
- 13 focused Flutter parser/widget/service and V1 regression tests passed.
- Targeted Dart static analysis of the V2A slice reported no issues.
- Full-project `flutter analyze --no-pub` timed out after 244.1 seconds without
  emitting a diagnostic and is not recorded as a pass.
- Synthetic tests are recorded only as software/math validation.
- No heavy/full-video pose inference, Stereo, Calibration, Multiview or OpenSim
  processing was performed.
- Flutter source changed during the final contract-integration audit; the prior
  13 focused Flutter pass applies only to the preceding revision.
- A final repeat of those three focused Flutter files emitted no output and
  timed out after 183.2 seconds; it is not recorded as a pass or source failure
  and does not supersede the earlier 13-test success.
- A later V2A-only two-file test command also produced no output before a
  259.3-second timeout. The timeout is not recorded as a pass or source
  failure; focused Python contract/API tests passed after the hardening.
- No Git staging, commit, push, merge, reset or destructive cleanup occurred.

## Three-Camera ChArUco Calibration Validation - 2026-08-08

### Session

- A new independent three-camera ChArUco calibration session was evaluated using:
  - Camera A: `20260808_202340.mp4`
  - Camera B: `IMG_2076.MOV`
  - Camera C: `IMG_6289.MOV`
- This session is independent from the previously evaluated two-camera calibration recordings.
- All three videos passed ChArUco preflight with high usable-view coverage.

### Intrinsic Calibration

- Camera A intrinsic calibration: `excellent`
  - RMS reprojection error: `0.2046 px`
  - Final valid views: `153`
- Camera B intrinsic calibration: `excellent`
  - RMS reprojection error: `0.2782 px`
  - Final valid views: `143`
- Camera C intrinsic calibration: `excellent`
  - RMS reprojection error: `0.3195 px`
  - Final valid views: `143`
- The three intrinsic calibration results are accepted as high-quality single-camera calibration artifacts for this recording configuration.

### Audio Synchronization

- A-B audio synchronization: `good`
  - Intercept: `+0.052679 s`
  - Drift: `+16.048 ppm`
  - Median correlation: `0.589664`
- A-C audio synchronization: `good`
  - Intercept: `-0.000417 s`
  - Drift approximately `0 ppm`
  - Median correlation: `0.520721`
- Direct B-C synchronization was additionally checked as a transitive consistency diagnostic.
- Stable-hold timeline analysis identified mismatched hold detections and demonstrated that audio synchronization alone must not be treated as sufficient evidence of geometric stereo synchronization.

### Extrinsic Calibration

- Initial A-B stereo extrinsic result:
  - Quality: `review_required`
  - RMS reprojection error: `7.2391 px`
  - Valid stereo views: `159`
  - Baseline: `0.284744 m`
- Initial A-C stereo extrinsic result:
  - Quality: `review_required`
  - RMS reprojection error: `10.0703 px`
  - Valid stereo views: `152`
  - Baseline: `0.406299 m`
- The extrinsic calibrator's internal fine-sync refinement was found capable of moving away from the externally supported audio/hold timing.
- A locked-offset calibration variant was therefore tested to prevent internal synchronization refinement.
- Locked A-B calibration remained `review_required`:
  - Locked offset: `+0.004467 s`
  - RMS reprojection error: `7.3447 px`
  - Valid stereo views: `153`
  - Baseline: `0.283276 m`
- Therefore the high stereo reprojection error cannot be accepted as merely an internal fine-sync-selection artifact.

### Independent Geometry Gate

- An independent ChArUco pose-relative geometry diagnostic was run for A-B using six robust timeline-matched stable holds.
- Result: `intrinsics_review_required`
- Valid paired poses: `6`
- Median Camera A single-view reprojection: `1.5177 px`
- Median Camera B single-view reprojection: `1.7922 px`
- Median relative-translation deviation: `0.033559 m` (`33.56 mm`)
- Median relative-rotation deviation: `5.718 deg`
- Median observed baseline: `0.334305 m`
- Observed baseline range: `0.301358-0.545761 m`
- The relative camera geometry is not sufficiently stable across independent paired board poses for scientific stereo reconstruction.

### Scientific Decision

- The 2026-08-08 three-camera session is **NOT approved for scientific 3D reconstruction**.
- No 3D athlete pose, biomechanical 3D metric, force, torque, moment, power or other spatial scientific claim may be derived from these extrinsic results.
- Excellent intrinsic calibration quality does not imply valid stereo extrinsic geometry.
- Good audio synchronization does not imply valid stereo geometry.
- High stereo pair count does not override failed independent geometry consistency.
- The generated `review_required` extrinsic artifacts must not be promoted to production/scientific calibration artifacts.
- The failure is retained as validation evidence rather than hidden or overwritten.
- No previously accepted single-camera analysis capability is downgraded by this three-camera stereo validation failure.

### Validation Status

- Three-camera intrinsic gate: `PASS`
- Audio synchronization gate: `PASS`
- Stereo extrinsic quality gate: `FAIL`
- Independent A-B geometry-consistency gate: `FAIL`
- Scientific 3D readiness: `BLOCKED`
- Single-camera scientific pipeline: unaffected




## JM-DEC-023 ? Attempt-Stable Identity / Event-Scoped Roles

### Architecture

- Separated persistent neutral subject identity from technique-event roles.
- Defined technique actor and target as event-scoped relationships.
- Added architectural support for initial attacks, follow-up attacks,
  combinations and counter-attacks within one attempt.
- Prevented permanent Tori/Uke assignment across a multi-event attempt.
- Prohibited belt/judogi color, image side and detection order as standalone
  identity or role rules.

### Human Ground Truth

- Recorded the human-selected Uchi Mata attempt boundary at `70.000-75.000 s`
  (`frame 1750` to `frame 1875`).
- Recorded human confirmation of the selected event performer.
- Recorded the human-confirmed right support leg.
- Exported the 100-frame annotation CSV for continued human review.
- No missing frame labels were inferred or defaulted.

### Scientific Safeguard

- Automatic attack/counter-attack classification remains unavailable pending
  independent validation.



### Human Annotation Progress ? Samples 000-024

- Completed human review of samples `#000-#024`.
- Ground-truth completion reached `25/100` review frames.
- Recorded visible-person counts, neutral subject references, occlusion and
  crossing labels for the reviewed samples.
- Preserved human-confirmed event performer and right support-leg evidence.
- Preserved role-neutral subject identity under `JM-DEC-023`.
- No unreviewed null value was converted to zero, false or another default.
- Source annotation drafts were preserved; a new create-only annotation
  artifact was written.



### Human Annotation Progress ? Samples 000-049

- Completed human review of samples `#025-#049`.
- Ground-truth completion reached `50/100` review frames.
- Recorded visible-person counts, neutral subject references, occlusion and
  crossing labels for the newly reviewed samples.
- Preserved human-confirmed event performer and right support-leg evidence.
- Preserved role-neutral subject identity under `JM-DEC-023`.
- No unreviewed null value was converted to zero, false or another default.
- Source annotation drafts were preserved; a new create-only annotation
  artifact was written.



### Human Annotation Progress ? Samples 000-074

- Completed human review of samples `#050-#074`.
- Ground-truth completion reached `75/100` review frames.
- Recorded visible-person counts, neutral subject references, occlusion and
  crossing labels for the newly reviewed samples.
- Preserved human-confirmed event performer and right support-leg evidence.
- Preserved role-neutral subject identity under `JM-DEC-023`.
- No unreviewed null value was converted to zero, false or another default.
- Source annotation drafts were preserved; a new create-only annotation
  artifact was written.



### Human Annotation Progress ? Samples 000-099

- Completed human review of samples `#075-#099`.
- Human frame review reached `100/100`.
- All 100 review samples now contain human-confirmed visible-person,
  neutral-subject, occlusion and crossing labels.
- Preserved the human-selected `70.000-75.000 s` reviewed attempt.
- Preserved the human-confirmed event performer and right support leg.
- Preserved the event-scoped role architecture defined by `JM-DEC-023`.
- No missing frame labels were inferred or defaulted.
- Source drafts were preserved through create-new annotation artifacts.
- Formal ground-truth finalization remains pending the readiness/finalizer gate.



### Uchi Mata Ground Truth Run 01 ? Complete

- Completed the first finalized 100-frame human-reviewed Uchi Mata ground-truth set.
- Passed the formal annotation readiness gate with:
  - `100/100` complete frames
  - `100/100` readable review assets
  - no missing human-review fields
  - no final validation errors
  - `labels_inferred_or_defaulted = false`
- Finalized the reviewed attempt `70.000-75.000 s`
  (`frame 1750` to `frame 1875`).
- Preserved the human-confirmed event performer and right support leg.
- Final artifact:
  `ai_engine/runtime/annotation_review/run01/uchi_mata_ground_truth_run01.json`
- Source drafts were preserved.
- `JM-DEC-023` remains the governing identity/event-role architecture.



### RTMPose-M Human Ground-Truth Detection Evaluation ? Run 01

- Evaluated the existing 100-frame RTMPose-M fast-screening observations
  against the finalized human-reviewed Uchi Mata Ground Truth Run 01.
- Reused existing inference; no new RTMPose-M inference was executed.
- Verified exact 100/100 frame/timestamp artifact alignment.
- Measured conditional >=1-person detection coverage of `98.96%`.
- Measured conditional two-person detection coverage of `47.92%`.
- Clear-frame two-person coverage reached `85.71%`.
- Two-person coverage decreased to `37.33%` with occlusion and `29.17%`
  with combined occlusion/crossing.
- Identified multi-person separation during close-contact judo interaction as
  the principal current detection bottleneck.
- Recorded results strictly as detection coverage; pose accuracy, identity
  accuracy and biomechanics accuracy remain unevaluated.



### Three-Engine Human Ground-Truth Detection Comparison ? Run 01

- Compared RTMPose-M, RTMO-M and MediaPipe-Heavy against the same finalized
  100-frame human-reviewed Uchi Mata Ground Truth Run 01.
- Reused existing inference artifacts; no new model inference was performed.
- RTMPose-M produced the highest overall two-person detection coverage
  (`47.92%`).
- RTMPose-M also produced the highest clear-frame two-person coverage
  (`85.71%`).
- During combined occlusion/crossing, RTMPose-M reached `29.17%`, versus
  `8.33%` for RTMO-M and `12.50%` for MediaPipe-Heavy.
- RTMPose-M is retained as the current detection baseline for further
  single-camera development.
- Its six detection-surplus frames remain a known issue requiring later
  false-positive review.
- Detection performance remains separate from pose, identity and biomechanics
  accuracy.



### RTMPose-M Failure-Frame Audit ? Run 01

- Audited all `50` detection-deficit and `6` detection-surplus frames against
  finalized human Ground Truth Run 01.
- Found that `49/50` deficit frames retained one detection while two judoka
  were human-visible.
- Only one deficit frame contained complete detection dropout.
- `47/50` deficits occurred with human-labelled occlusion.
- Identified second-person preservation/separation during close-contact judo
  as the primary current detection investigation target.
- Retained the six detection-surplus frames for explicit false-positive review.
- No new inference was executed.



### JM-DEC-024 ? RTMPose-M Failure Localization Complete

- Rebuilt the close-contact diagnostic against the original benchmark video.
- Reproduced all 12 representative historical RTMPose-M counts exactly.
- Confirmed that most selected two-person deficits already originate with only
  one detector box.
- Confirmed a smaller downstream pose-validity failure mode.
- Confirmed that selected surplus detections also originate with surplus
  detector boxes.
- Retained RTMPose-M as the current pose baseline.
- Localized the next engineering target to close-contact person detection.
- Closed the diagnostic branch to prevent repeated diagnostic cycling.



### Bounded Detector Score-Threshold Experiment ? Run 01

- Tested one pre-registered YOLOX score-threshold change from `0.70` to `0.50`.
- Re-evaluated the same 100 human-ground-truth frames.
- Observed no change in two-person coverage, occlusion/crossing coverage,
  detection deficits or surplus detections.
- Improvement gate failed.
- Closed score-threshold tuning without testing additional threshold values.
- Production configuration remains unchanged.
- RTMPose-M remains the current baseline with known close-contact
  multi-person limitations.



### Multi-Person Evidence Capability Gate

- Added `MultiPersonEvidenceStatus` to the Single Attempt V2A contract.
- Added explicit multi-person evidence capability state.
- Added `multi_person_interaction_metrics_reportable = false`.
- Default multi-person evidence status is `insufficient`.
- Verified the capability contract with direct assertions.
- Existing metric calculations and inference pipeline were not changed.



### Single Attempt V2A Response Multi-Person Gate

- Wired `SingleAttemptCapabilities` explicitly into the real
  `analyze_single_attempt()` response.
- Added API assertions for:
  - `multi_person_evidence_status = insufficient`
  - `multi_person_interaction_metrics_reportable = false`
- Ran the existing Single Attempt V2A API test suite.
- Result: `4/4 PASS`.
- Existing metric behavior and fail-closed scientific boundaries were preserved.
- No model inference or detector changes were performed.



### Boundary-Normalized Landmark Reporting Gate

- Added explicit `boundary_normalized_landmarks` provenance to
  `PoseObservation2D`.
- Added a reporting gate preventing metrics that depend on boundary-normalized
  landmarks from becoming automatically reportable.
- Preserved the metric value for human review rather than silently discarding
  it.
- Re-evaluated the existing V2A artifact without new pose inference.
- Run 01 status:
  - duration: reportable
  - trunk inclination: review_required
  - support-leg knee angle: reportable
- Added and passed a dedicated unittest regression test.



### UM-ANG-003 ? Projected Attacking-Leg Knee Angle

- Added `AttackingLegSelection` to the Single Attempt V2A request/response contract.
- Attacking-leg classification requires `human-confirmed` provenance.
- Added `UM-ANG-003` to the approved V2A metric registry.
- Reused the approved `projected-knee-angle-1.0.0` image-plane method.
- Reused the existing metric-specific boundary-normalization reporting gate.
- Added fail-closed behavior: missing attacking-leg confirmation withholds the metric.
- Run 01 result: `157.99 deg`, `reportable`.
- Added and passed two dedicated unittest regression tests.
- No new pose inference was required for Run 01.



### UM-ANG-004 Method Definition Gate

- Reviewed the existing scientific registry for `UM-ANG-004`.
- Determined that the current specification does not define a sufficiently
  precise versioned image-plane hip-angle method for implementation.
- Deferred implementation rather than inventing a formula.
- No production or inference changes were made.



### V2A Four-Metric Regression Stability

- Updated the existing V2A API regression expectation from three to four metrics.
- Ran the targeted V2A regression suite after `UM-ANG-003` integration.
- Result: `9/9 PASS`.
- Confirmed no regression in:
  - missing-pose fail-closed behavior;
  - API/OpenAPI contract;
  - boundary-normalization reporting gate;
  - human-confirmed attacking-leg validation;
  - `UM-ANG-003` fail-closed behavior.
- No new inference was performed.


### Experimental Neutral Identity Tracker Prototype

- Added a project-owned `ExperimentalRTMLibIoUTracker` implementing the
  existing `NeutralIdentityTracker` Protocol outside the production V2A path.
- Reused RTMLib `0.0.16` `compute_iou` and its default strict
  `IoU > 0.3` baseline without presenting the threshold as scientifically
  validated.
- Kept all identities role-neutral and all association provenance
  `AI-inferred`; no Tori/Uke role is produced.
- Kept `association_confidence=None` and explicitly records
  `association_confidence_unavailable` rather than converting IoU into a
  confidence score.
- Added fail-closed behavior for ambiguous multi-candidate overlap,
  multi-person detection collapse/occlusion risk, disappearance and unverified
  reappearance. Lost identities are not silently restored.
- Added synthetic coverage for neutral track creation, stable continuation,
  detection-order changes, ambiguity, disappearance, occlusion collapse,
  unverified reappearance, reset, one-to-one assignment, unavailable
  confidence and role-label exclusion.
- Existing identity-contract plus prototype tests pass `29/29`; syntax
  compilation passes.
- No model/video inference, V2A production change, scientific-metric change,
  package installation or JM-DEC-024 change was performed.
